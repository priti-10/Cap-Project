package com.user.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.entities.User;
import com.user.repository.UserRepository;
import com.user.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository repo;
	
	@Override
	public User add(User user) {
		
		return repo.save(user);
	}

	@Override
	public String delete(int userId) {
		
		repo.deleteById(userId);
		return "Deleted..........";
	}

	@Override
	public List<User> getUserByRole(String role) {
		
		return repo.getByRole(role);
	}

	@Override
	public User getUserById(int userId) {
		
		return repo.findById(userId).get();
	}

	@Override
	public List<User> getUsers() {
		
		return repo.findAll();
	}

}
