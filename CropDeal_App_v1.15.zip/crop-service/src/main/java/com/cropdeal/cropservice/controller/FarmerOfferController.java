package com.cropdeal.cropservice.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cropdeal.cropservice.dto.CalculateDto;
import com.cropdeal.cropservice.dto.FarmerDetailDto;
import com.cropdeal.cropservice.dto.FarmerDto;
import com.cropdeal.cropservice.dto.VolumeDto;
import com.cropdeal.cropservice.model.FarmerOffer;
import com.cropdeal.cropservice.service.FarmerOfferService;

@RestController
@RequestMapping("/crop/farmer")
public class FarmerOfferController {
	private FarmerOfferService farmerService;


	public FarmerOfferController(FarmerOfferService farmerService) {
		super();
		this.farmerService = farmerService;
	}

	@PostMapping("/add/offer/{cropId}")
	public FarmerOffer addOffer(@RequestBody FarmerOffer farmerOffer,@PathVariable int cropId) throws HttpRequestMethodNotSupportedException {
		return farmerService.addOffer(cropId,farmerOffer);
	}

	@GetMapping("/get/offerid/{farmerOfferId}")
	public FarmerOffer getFarmerOffer(@PathVariable int farmerOfferId) {
		return farmerService.getFarmerOffer(farmerOfferId);
	}

	@GetMapping("/getall/farmerid/{farmerid}")
	public List<FarmerOffer> getAllFramerOffersById(@PathVariable int farmerid) {
		return farmerService.getAllFramerOffersById(farmerid);
	}
	
	@GetMapping("/get/cropbystate/{state}")
	public List<FarmerOffer> getCropByState(@PathVariable String state){
		return farmerService.getCropByState(state);
	}
	
	@GetMapping("/get/cropbycity/{city}")
	public List<FarmerOffer> getCropByCity(@PathVariable String city){
		return farmerService.getCropByCity(city);
	}
	

	@PutMapping("/update/offerid/{farmerOfferId}")
	public FarmerOffer updateFarmerOffer(@PathVariable int farmerOfferId, @RequestBody FarmerOffer farmerOffer) {
		return farmerService.updateFarmerOffer(farmerOfferId, farmerOffer);
	}
	
	@PutMapping("/update/farmercrop")
	public FarmerOffer updateFarmerCropEntity(@RequestBody FarmerDto farmerDto) {
		return farmerService.updateFarmerCropEntity(farmerDto);
	}

	@DeleteMapping("/delete/offerid/{farmerOfferId}")
	public FarmerOffer deleteFramerOfferById(@PathVariable int farmerOfferId) {
		return farmerService.deleteFramerOfferById(farmerOfferId);
	}

	@PostMapping("/get/total")
	public double calculateTotal(@RequestBody CalculateDto calculateDto) {
		return farmerService.calculateTotal(calculateDto);
	}
	
	@PostMapping("/get/totalforeach")
	public Map<String,Double> getCropOrderWithNameList(@RequestBody CalculateDto calculateDto){
		return farmerService.getCropOrderWithNameList(calculateDto);
	}
	
	@PostMapping("/get/farmerdetails")
	public List<FarmerDetailDto> getFarmerDetailsForDealer(@RequestBody CalculateDto calculateDto){
		return farmerService.getFarmerDetailsForDealer(calculateDto);
	}
	
	@PostMapping("/get/availability")
	public boolean checkAvailabilityOfCropVolume(@RequestBody VolumeDto volumeDto) {
		return farmerService.checkAvailabilityOfCropVolume(volumeDto);
	}
	
	@PostMapping("/set/availability")
	public boolean setAvailabilityOfCropVolume(@RequestBody VolumeDto volumeDto) {
		return farmerService.setAvailabilityOfCropVolume(volumeDto);
	}
	
	@PostMapping("/set/volumetodb")
	public boolean setCropVolumeBackToDB(@RequestBody VolumeDto volumeDto) {
		return farmerService.setCropVolumeBackToDB(volumeDto);
	}
	
	
}
