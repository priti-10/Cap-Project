package com.order.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.entities.Order;
import com.order.repository.OrderRepository;
import com.order.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService{
	    @Autowired 
	    private OrderRepository orderRepository;

	    // Fetch all orders
	    public List<Order> getAllOrders() {
	        return orderRepository.findAll();
	    }

	    // Fetch a single order by ID
	    public Order getOrderById(int orderId) {
	        Optional<Order> order = orderRepository.findById(orderId); // Check if the order exists
	        return order.orElse(null); // Return order if found, otherwise return null
	    }

	    // Fetch orders placed by a specific buyer
	    public List<Order> getOrdersByBuyer(int buyerId) {
	        return orderRepository.findByBuyerId(buyerId);
	    }

	    // Fetch orders assigned to a specific farmer
	    public List<Order> getOrdersByFarmer(int farmerId) {
	        return orderRepository.findByFarmerId(farmerId);
	    }

	    // Add a new order
	    public Order addOrder(Order order) {
	        return orderRepository.save(order); // Save the order in the database
	    }

//	    // Update an existing order
//	    public Order updateOrder(int orderId, Order updatedOrder) {
//	        Optional<Order> existingOrder = orderRepository.findById(orderId); // Check if order exists
//	        if (existingOrder.isPresent()) {
//	            Order order = existingOrder.get();
//	            order.setTotalPrice(updatedOrder.getTotalPrice());
//	            order.setQuantity(updatedOrder.getQuantity());
//	            order.setStatus(updatedOrder.getStatus());
//	            return orderRepository.save(order); // Save the updated order
//	        }
//	        return null;
//	    }

//	    // Delete an order by ID
//	    public String deleteOrder(int orderId) {
//	        orderRepository.deleteById(orderId);
//	        return "Order deleted successfully!";
//	    }


}
