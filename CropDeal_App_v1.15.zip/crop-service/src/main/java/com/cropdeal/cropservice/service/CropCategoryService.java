package com.cropdeal.cropservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cropdeal.cropservice.exception.ApiRequestException;
import com.cropdeal.cropservice.model.CropCategory;
import com.cropdeal.cropservice.repository.CropCategoryRepo;

@Service
public class CropCategoryService {

	private CropCategoryRepo categoryRepo;
	private String messageCategoryNotFound="CropCategory not Found!";
	
	public CropCategoryService(CropCategoryRepo categoryRepo) {
		super();
		this.categoryRepo = categoryRepo;
	}

	public CropCategory addCropCategory(CropCategory cropCategory) {
		return categoryRepo.save(cropCategory);
	}

	public CropCategory getCropCategory(int categoryId) {
		Optional<CropCategory> foundCategory=categoryRepo.findById(categoryId);
		if(foundCategory.isEmpty()) {
			throw new ApiRequestException(messageCategoryNotFound);
		}
		return foundCategory.get();
	}

	public List<CropCategory> getAllCropCategory() {
		if(categoryRepo.findAll().isEmpty())
		{
			throw new ApiRequestException("No Crop Added!");
		}
		return categoryRepo.findAll();
	}

	public CropCategory updateCropCategory(int categoryId, CropCategory category) {
		Optional<CropCategory> foundCategory= categoryRepo.findById(categoryId);
		if(foundCategory.isPresent()) {
			foundCategory.get().setCategoryName(!category.getCategoryName().isEmpty()?category.getCategoryName():foundCategory.get().getCategoryName());
			return  categoryRepo.save(foundCategory.get());
		}else {
			throw new ApiRequestException(messageCategoryNotFound);
		}
		
	}

	public CropCategory deleteCropCategory(int categoryId) {
		Optional<CropCategory> foundCategory= categoryRepo.findById(categoryId);
		if(foundCategory.isPresent()) {
			categoryRepo.delete(foundCategory.get());
			return foundCategory.get();
		}else {
			throw new ApiRequestException("CropCategory not Found!");
		}
		 
	}
	
}
