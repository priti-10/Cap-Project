package com.cropdeal.cropservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cropdeal.cropservice.model.CropEntity;

@Repository
public interface CropEntityRepo extends JpaRepository<CropEntity, Integer>{

}
