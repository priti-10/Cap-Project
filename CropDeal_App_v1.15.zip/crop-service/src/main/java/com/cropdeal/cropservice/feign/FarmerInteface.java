package com.cropdeal.cropservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cropdeal.cropservice.dto.FarmerDetailDto;


@FeignClient("USER-SERVICE")
public interface FarmerInteface {

	@GetMapping("/auth/farmer/get/detail/{farmerId}")
	public ResponseEntity<FarmerDetailDto> getFarmerDetails(@PathVariable int farmerId);
}
