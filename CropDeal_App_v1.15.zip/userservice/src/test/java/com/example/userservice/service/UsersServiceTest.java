package com.example.userservice.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.example.userservice.dto.UserDto;
import com.example.userservice.model.UserAdmin;
import com.example.userservice.model.Users;
import com.example.userservice.repository.UsersRepo;

@ExtendWith(MockitoExtension.class)
class UsersServiceTest {
	
	@Mock
	private UsersRepo usersRepo;
	
	@Mock
	private JwtService jwtService;
	
	@Mock
	Authentication authentication;
	
	@Mock
	AuthenticationManager authmanager;
	
	@Mock
	private PasswordEncoder passwordEncoder;
	
	Users user;
	UserDto userDto;
	
	@InjectMocks
	UsersService usersService;
	
	@BeforeEach
	void setUp() {
		user=new Users("krishna","k@123","ADMIN");
		userDto=new UserDto("krishna","k@123");
	}

	@Test
	void testAddUser() {
		mock(Users.class);
		mock(UsersRepo.class);
		
		when(usersRepo.save(any(Users.class))).thenReturn(user);
		
		assertThat(usersService.addUser(user).getUsername()).isEqualTo(user.getUsername());
	}

	@Test
	void testVerify() {
		mock(Authentication.class);
		mock(AuthenticationManager.class);
		mock(JwtService.class);
		
		
		when(authmanager.authenticate(new UsernamePasswordAuthenticationToken(userDto.getUsername(), userDto.getPassword()))).thenReturn(authentication);
		
		when(authentication.isAuthenticated()).thenReturn(true);
		
		when(jwtService.generateToken(userDto.getUsername())).thenReturn("SecretKey");
		
		assertThat(usersService.verify(userDto)).isEqualTo("SecretKey");
	}

	@Test
	void testGetAllUsers() {
		mock(Users.class);
		mock(UsersRepo.class);
		Users userAdmin=new UserAdmin("krish","k@123","ADMIN,DEALER","Dev");
		
		when(usersRepo.findAll()).thenReturn(Arrays.asList(user,userAdmin));
		
		assertThat(usersService.getAllUsers().get(0).getPassword()).isEqualTo(user.getPassword());
		assertThat(usersService.getAllUsers().get(1).getRoles()).isEqualTo(userAdmin.getRoles());
		
	}

}
