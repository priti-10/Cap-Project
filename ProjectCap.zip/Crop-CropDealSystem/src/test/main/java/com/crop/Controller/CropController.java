package com.crop.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crop.entities.Crop;
import com.crop.service.CropService;
import com.crop.service.impl.CropServiceImpl;

@RestController
@RequestMapping("/crops")
public class CropController {
	
	
	@Autowired
	private CropServiceImpl service;
	
	@GetMapping
	public String home() {
		return "Welcome to the Crop Management System!";
	}
	
	@GetMapping("/view")
	public List<Crop> getAllCrops(){
		return service.getAllCrops();
	}
	
	@GetMapping("/viewbyid/{cropId}")
	public Crop getCropById(@PathVariable int cropId) {
		return service.getCropById(cropId);
	}
	
	@GetMapping("/viewbyfarmer/{farmerId}")
	public List<Crop> getCropsByFarmer(@PathVariable int farmerId){
		return service.getCropsByFarmer(farmerId);			
	}
	
	@PostMapping("/add")
	public Crop addCrop(@RequestBody Crop crop) {
		return service.addCrop(crop);
	}
	
	@PutMapping("/update")
	public Crop updateCrop(@RequestBody Crop crop) {
		return service.updateCrop(crop);
	}
	
	@DeleteMapping("/delete/{cropId}")
	public String deleteCrop(@PathVariable int cropId) {
		return service.deleteCrop(cropId);
	}
}
