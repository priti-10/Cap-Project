package com.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.service.UserService;
import com.user.service.impl.UserServiceImpl;
import com.user.entities.Crop;
import com.user.entities.Order;
import com.user.entities.User;
import com.user.feignclient.FeignToCrop;
import com.user.feignclient.FeignToOrder;

@RestController
@RequestMapping("/users")
public class UserController {
	
	@Autowired
	private UserServiceImpl service;
	
	@Autowired
	private FeignToCrop feigncrop;
	
	@Autowired
	private FeignToOrder feignorder;
	
	@GetMapping
	public String home(){
		return "We are in Home..........!!!";
	}

	@GetMapping("/view")
	public List<User> get()
	{
		return service.getUsers();
	}
	
	@GetMapping("/viewbyid/{userId}")
	public User getbyid(@PathVariable int userId)
	{
		return service.getUserById(userId);
	}
	
	@GetMapping("/viewbyrole/{role}")
	public List<User> getbyrole(@PathVariable String role)
	{
		return service.getUserByRole(role);
	}
	
	@PostMapping("/add")
	public User add(@RequestBody User user)
	{
		user.setRole(user.getRole().toUpperCase());
		if(user.getRole().equals("FARMER") || user.getRole().equals("BUYER"))
		{
			return service.add(user);
		}
		else return null;
		
	}
	
	@DeleteMapping("/delete/{userId}")
	public String delete(@PathVariable int userId)
	{
		return service.delete(userId);
	}
	
	@GetMapping("/purchase/{userId}/{cropId}")
	public Order purchase(@PathVariable int userId, @PathVariable int cropId)
	{
		System.out.println("asdfghjk");
		User user = getbyid(userId);
		Crop crop = feigncrop.fetchCropById(cropId);
		
		Order order = new Order(user.getUserId(),user.getName(),crop.getFarmerId(),
				crop.getFarmerName(),crop.getCropId(),crop.getCropName(),crop.getPricePerKg()*crop.getQuantityInKg(),crop.getQuantityInKg());
		
		String result = feigncrop.deleteCropById(cropId);
		System.out.println(result);
		return feignorder.addOrderObject(order);
		
	}
}
