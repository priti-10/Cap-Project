package com.example.userservice.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DealerDetailDto {

	private int dealerUserId;
	private String username;
	private String email;
	private String phoneNumber;
	private String address;
	private String city;
	private String state;
	private String businessName;
}
