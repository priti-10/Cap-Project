package com.cropdeal.cropservice.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class FarmerOffer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int farmerOfferId;
	private int farmerId;
	private int perKiloPrice;
	private double totalCapacity;
	
	private String email;
	private String phoneNumber;
	private String city;
	private String state;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "crop_id")
	@JsonIgnoreProperties("farmerOffer")
	private CropEntity farmerCropEntity;
} 
