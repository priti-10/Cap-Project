package com.cropdeal.cropservice.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import feign.FeignException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value = { ApiRequestException.class })
	ResponseEntity<ExceptionEntity> handleApiRequestException(ApiRequestException ex) {

		return buildResponse(ex.getMessage(), HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();
		for (FieldError error : ex.getBindingResult().getFieldErrors()) {
			errors.put(error.getField(), error.getDefaultMessage());
		}
		return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(FeignException.class)
	public ResponseEntity<ExceptionEntity> handleFeignException(FeignException ex) {
		String responseBody = ex.contentUTF8();
		return buildResponse(responseBody, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<ExceptionEntity> handleHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException ex) {
		return buildResponse(ex.getMessage(), HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<ExceptionEntity> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException ex) {
		return buildResponse(ex.getMessage(), HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(NoResourceFoundException.class)
	public ResponseEntity<ExceptionEntity> handleNoResourceFoundException(NoResourceFoundException ex) {
		return buildResponse(ex.getMessage(), HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ExceptionEntity> handleGeneralException(Exception ex) {
		ex.printStackTrace();
		return buildResponse("An unexpected error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private ResponseEntity<ExceptionEntity> buildResponse(String message, HttpStatus status) {
		ExceptionEntity entity = new ExceptionEntity(message, status.value(), status.getReasonPhrase(),
				LocalDateTime.now());
		return new ResponseEntity<>(entity, status);
	}
}
