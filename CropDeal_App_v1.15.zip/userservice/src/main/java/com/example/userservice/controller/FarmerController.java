package com.example.userservice.controller;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.userservice.dto.FarmerDetailDto;
import com.example.userservice.dto.UserDto;
import com.example.userservice.model.UserFarmer;
import com.example.userservice.service.UsersService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth/farmer")
public class FarmerController {

	public FarmerController(UsersService usersService) {
		super();
		this.usersService = usersService;
	}

	private UsersService usersService;

	@PostMapping("/register")
	public UserFarmer addFarmer(@Valid @RequestBody UserFarmer userFarmer) {
		userFarmer.setCreatedDateTime(LocalDateTime.now());
		return (UserFarmer) usersService.addUser(userFarmer);
	}

	@PostMapping("/login")
	public String login(@Valid @RequestBody UserDto user) {
		return usersService.verify(user);
	}
	
	@GetMapping("/{username}")
	public ResponseEntity<UserFarmer> getProfile(@PathVariable String username) {
		return new ResponseEntity<>((UserFarmer)usersService.getProfile(username),HttpStatus.OK);
	}
	
	@GetMapping("/get/detail/{farmerId}")
	public ResponseEntity<FarmerDetailDto> getFarmerDetails(@PathVariable int farmerId){
		return new ResponseEntity<>(usersService.getFarmerDetails(farmerId),HttpStatus.OK);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<UserFarmer> updateProfile(@RequestBody UserFarmer user, @PathVariable int id){
		return new ResponseEntity<>(usersService.updateFarmerProfile(user,id),HttpStatus.CREATED);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteProfile(@PathVariable int id) {
		return  new ResponseEntity<>(usersService.deleteProfile(id),HttpStatus.OK);
	}

}
