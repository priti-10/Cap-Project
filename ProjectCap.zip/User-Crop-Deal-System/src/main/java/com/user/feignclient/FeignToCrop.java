package com.user.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.user.entities.Crop;

@FeignClient(name="CROP-CROPDEALSYSTEM")
public interface FeignToCrop {
	
	@GetMapping("/crops/viewbyid/{cropId}")
	public Crop fetchCropById(@PathVariable int cropId);
	
	@DeleteMapping("/crops/delete/{cropId}")
	public String deleteCropById(@PathVariable int cropId);
}
