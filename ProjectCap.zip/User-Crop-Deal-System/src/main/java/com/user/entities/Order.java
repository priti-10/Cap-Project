package com.user.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

public class Order {
	
    private int orderId;
    private int buyerId;
    private String buyerName;
    private int farmerId;
    private String farmerName;
    private int cropId;
    private String cropName;
    private double totalPrice;
    private int quantity;
    
	public Order() {
		
	}
	public Order(int buyerId, String buyerName, int farmerId, String farmerName, int cropId,
			String cropName, double totalPrice, int quantity) {
		super();
		//this.orderId = orderId;
		this.buyerId = buyerId;
		this.buyerName = buyerName;
		this.farmerId = farmerId;
		this.farmerName = farmerName;
		this.cropId = cropId;
		this.cropName = cropName;
		this.totalPrice = totalPrice;
		this.quantity = quantity;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}
	public String getBuyerName() {
		return buyerName;
	}
	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}
	public int getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}
	public String getFarmerName() {
		return farmerName;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public int getCropId() {
		return cropId;
	}
	public void setCropId(int cropId) {
		this.cropId = cropId;
	}
	public String getCropName() {
		return cropName;
	}
	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}

