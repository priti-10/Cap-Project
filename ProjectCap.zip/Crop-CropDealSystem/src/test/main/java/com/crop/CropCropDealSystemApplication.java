package com.crop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CropCropDealSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CropCropDealSystemApplication.class, args);
	}

}
