package com.cropdeal.cropservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FarmerDto {

	private int farmerOfferId;
	private int farmerId;
	private int perKiloPrice;
	private int totalCapacity;
	private int cropId;
	private String city;
	private String state;
}
