package com.cropdeal.cropservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cropdeal.cropservice.model.FarmerOffer;

@Repository
public interface FarmerOfferRepo extends JpaRepository<FarmerOffer, Integer> {

	List<FarmerOffer> findAllByFarmerId(int farmerId);

	List<FarmerOffer> findAllByState(String state);

	List<FarmerOffer> findAllByCity(String city);

}
