package com.cropdeal.apigateway.filter;

import java.util.List;
import java.util.function.Predicate;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import com.cropdeal.apigateway.exception.NotAuthorizedException;
import com.cropdeal.apigateway.service.JwtService;

@Component
public class RouteValidator {

	private JwtService jwtService;
	private String unauthorizedAccessMessage = "Unauthorized Access to URI!";

	public RouteValidator(JwtService jwtService) {
		super();
		this.jwtService = jwtService;
	}

	public static final List<String> openApiEndpoints = List.of(
																"/auth/register",
																"/auth/admin/login",
																"/auth/farmer/register",
																"/auth/farmer/login",
																"/auth/dealer/register",
																"/auth/dealer/login",
																"/eureka");

	public static final List<String> adminApiEndpoints = List.of("/auth/admin/getAllProfile",
																	"/auth/admin/.*",
																	"/auth/farmer/.*",
																	"/auth/dealer/.*",
																	"/order/.*",
																	"/crop/.*");

	public static final List<String> farmerApiEndpoints = List.of(  "/auth/farmer/.*",
																	"/crop/farmer/.*");

	public static final List<String> dealerApiEndpoints = List.of( "/auth/dealer/.*",
																	"/order/.*");

	public final Predicate<ServerHttpRequest> isSecured=
			request -> openApiEndpoints.stream()
			.noneMatch(uri->request.getURI().getPath().contains(uri));

	public boolean validAdminrequest(ServerHttpRequest request) {
		String uri = request.getURI().getPath();

//		return adminApiEndpoints.stream().anyMatch(s->uri.matches(s));
		return adminApiEndpoints.stream().anyMatch(uri::matches);
	}

	public boolean validFarmerrequest(ServerHttpRequest request) {
		String uri = request.getURI().getPath();

		return farmerApiEndpoints.stream().anyMatch(uri::matches);
	}

	public boolean validDealerrequest(ServerHttpRequest request) {
		String uri = request.getURI().getPath();

		return dealerApiEndpoints.stream().anyMatch(uri::matches);
	}

	public void validUserToUri(String authHeader, ServerWebExchange exchange) {
		List<String> roles = jwtService.getRolesFromToken(authHeader);
		if(roles.isEmpty()) {
			throw new NotAuthorizedException("No Roles Found!" + unauthorizedAccessMessage); 
		}
		
		if(!validateNonAdminUsers(roles, exchange))
			throw new NotAuthorizedException(unauthorizedAccessMessage);

	}

		private boolean validateNonAdminUsers(List<String> roles,ServerWebExchange exchange) {
			for (String s : roles) {
				
				if (s.equals("ROLE_ADMIN") && validAdminrequest(exchange.getRequest()))
					return true;
				if (s.equals("ROLE_DEALER") && validDealerrequest(exchange.getRequest()))
					return true;
				if (s.equals("ROLE_FARMER") && validFarmerrequest(exchange.getRequest()))
					return true;
			  }
			return false;
		}
		
}
