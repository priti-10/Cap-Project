package com.example.userservice.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.userservice.model.Users;

@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
class UsersRepoTest {

    @Autowired
    private UsersRepo usersRepo;
    
    private Users users;

    @BeforeEach
    void setUp() {
        users = new Users("Peter", "1234", "ADMIN");
        usersRepo.save(users);
    }

    @AfterEach
    void tearDown() {
        usersRepo.deleteAll();
    }

    @Test
    void testFindByUsername() {
        Users user = usersRepo.findByUsername("Peter");
        assertNotNull(user, "User should not be null");
        assertEquals(users.getPassword(), user.getPassword());
        assertEquals(users.getRoles(), user.getRoles());
    }
    
    @Test
    void testFindByUsernameNotFound() {
    	Users user = usersRepo.findByUsername("krishna");
    	assertNull(user);
    }
}
