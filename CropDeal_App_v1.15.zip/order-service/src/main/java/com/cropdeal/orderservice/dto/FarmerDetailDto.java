package com.cropdeal.orderservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class FarmerDetailDto {

	private int farmerUserId;
	private String email;
	private String phoneNumber;
	private String city;
	private String state;
	 
}
