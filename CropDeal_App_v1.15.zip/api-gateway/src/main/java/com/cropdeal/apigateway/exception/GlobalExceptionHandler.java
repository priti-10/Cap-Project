package com.cropdeal.apigateway.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value = { NotAuthenticatedException.class })
	ResponseEntity<ExceptionEntity> handleNotAuthenticatedException(NotAuthenticatedException ex) {

		return buildResponse(ex.getMessage(), HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(value = { NotAuthorizedException.class })
	ResponseEntity<ExceptionEntity> handleNotAuthorizedException(NotAuthorizedException ex) {

		return buildResponse(ex.getMessage(), HttpStatus.FORBIDDEN);
	}
	@ExceptionHandler(InvalidTokenException.class)
	ResponseEntity<ExceptionEntity> handleInvalidToken(InvalidTokenException ex){
		
		return buildResponse(ex.getMessage(), HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(value = {TokenExpiredException.class})
	ResponseEntity<ExceptionEntity> handleTokenExpired(TokenExpiredException ex){
		
		return buildResponse(ex.getMessage(), HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(value = {JwtAuthenticationException.class})
	ResponseEntity<ExceptionEntity> handleJwtAuthentication(JwtAuthenticationException ex){
		
		return buildResponse(ex.getMessage(), HttpStatus.FORBIDDEN);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ExceptionEntity> handleGeneralException(Exception ex) {
		ex.printStackTrace();
		return buildResponse("An unexpected error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	private ResponseEntity<ExceptionEntity> buildResponse(String message, HttpStatus status) {
		ExceptionEntity entity = new ExceptionEntity(message, status.value(), status.getReasonPhrase(),
				LocalDateTime.now());
		return new ResponseEntity<>(entity, status);
	}
}
