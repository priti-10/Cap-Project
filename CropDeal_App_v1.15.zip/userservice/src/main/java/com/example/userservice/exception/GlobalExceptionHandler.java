package com.example.userservice.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;



@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(value = {ApiRequestException.class})
	ResponseEntity<ExceptionEntity> handleApiRequestException(ApiRequestException ex){
		
		return buildResponse(ex.getMessage(), HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(InvalidTokenException.class)
	ResponseEntity<ExceptionEntity> handleInvalidToken(InvalidTokenException ex){
		
		return buildResponse(ex.getMessage(), HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(value = {TokenExpiredException.class})
	ResponseEntity<ExceptionEntity> handleTokenExpired(TokenExpiredException ex){
		
		return buildResponse(ex.getMessage(), HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(value = {JwtAuthenticationException.class})
	ResponseEntity<ExceptionEntity> handleJwtAuthentication(JwtAuthenticationException ex){
		
		return buildResponse(ex.getMessage(), HttpStatus.FORBIDDEN);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
//        ex.getBindingResult().getAllErrors().forEach(error -> {
//            String fieldName = ((FieldError) error).getField();
//            String errorMessage = error.getDefaultMessage();
//            errors.put(fieldName, errorMessage);
//        });
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            errors.put(error.getField(), error.getDefaultMessage());
        }
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }
	
	@ExceptionHandler(Exception.class)
    public ResponseEntity<ExceptionEntity> handleGeneralException(Exception ex) {
		ex.printStackTrace();
        return buildResponse("An unexpected error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
    }
	
	
	
	private ResponseEntity<ExceptionEntity> buildResponse(String message,HttpStatus status){
		ExceptionEntity entity=new ExceptionEntity(message, status.value(), status.getReasonPhrase(), LocalDateTime.now());
		return new ResponseEntity<>(entity,status);
	}
}
