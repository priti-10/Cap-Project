package com.cropdeal.apigateway.exception;

public class NotAuthenticatedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotAuthenticatedException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public NotAuthenticatedException(String message) {
		super(message);
		
	}

	
}
