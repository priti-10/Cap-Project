package com.cropdeal.apigateway.service;


//import java.security.Key;
//import java.security.NoSuchAlgorithmException;
//import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

//import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

//import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.cropdeal.apigateway.exception.InvalidTokenException;
import com.cropdeal.apigateway.exception.JwtAuthenticationException;
import com.cropdeal.apigateway.exception.TokenExpiredException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;

@Service
public class JwtService {

	private String secretKey="MWB1e7n+YZ0vnwa2oxYQnEYWviDb68258/tpl+SOpJM=";
	
	
//	public JwtService() {
//		try {
//			KeyGenerator keyGen= KeyGenerator.getInstance("HmacSHA256");
//			SecretKey sk=keyGen.generateKey();
//			secretKey = Base64.getEncoder().encodeToString(sk.getEncoded());
//		} catch (NoSuchAlgorithmException e) {
//			
////			e.printStackTrace();
//			throw new RuntimeException(e);
//		}
//	}
	
	public String generateToken(String username) {
		
		Map<String,Object> claims=new HashMap<>();
		
		
		
		return Jwts.builder()
				.claims()
				.add(claims)
				.subject(username)
				.issuedAt(new Date(System.currentTimeMillis()))
				.expiration(new Date(System.currentTimeMillis()+60*60*30))
				.and()
				.signWith(getKey())
				.compact();
		
//		return null;
	}

	private SecretKey getKey() {
//		System.out.println(secretKey);
		byte[] keyBytes= Decoders.BASE64.decode(secretKey);
		return Keys.hmacShaKeyFor(keyBytes);
	}

	@SuppressWarnings("unchecked")
	public List<String> getRolesFromToken(String token){
		Claims claims=extractAllClaims(token);
		return claims.get("roles",List.class);
	}
	
	public String extractUserName(String token) {
		
		return extractClaim(token, Claims::getSubject);
	}

	private <T> T extractClaim(String token, Function<Claims,T> claimResolver) {
		final Claims claims= extractAllClaims(token);
		return claimResolver.apply(claims);
	}

	private Claims extractAllClaims(String token) {
		try {
			return Jwts.parser()
					.verifyWith(getKey())
					.build()
					.parseSignedClaims(token)
					.getPayload();
			}catch(ExpiredJwtException e) {
				throw new TokenExpiredException("JWT Token has expired");
			}catch(SignatureException e) {
				 throw new InvalidTokenException("Invalid JWT signature");
			}catch (MalformedJwtException e) {
	            throw new InvalidTokenException("Malformed JWT token");
	        } catch (UnsupportedJwtException e) {
	            throw new InvalidTokenException("JWT token is not supported");
	        } catch (IllegalArgumentException e) {
	            throw new JwtAuthenticationException("JWT claims string is empty");
	        }
	}

	public boolean validateToken(String token) {
		return  !isTokenExpired(token);
	}

	private boolean isTokenExpired(String token) {
		
		return extractExpiration(token).before(new Date());
	}

	private Date extractExpiration(String token) {
		
		return extractClaim(token, Claims::getExpiration);
	}

}

