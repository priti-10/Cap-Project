package com.example.userservice.model;



import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@DiscriminatorValue("AD")
@Entity
public class UserAdmin extends Users {
		

	public UserAdmin(String username, String password, String roles, String department) {
		super(username,password,roles);
		this.department=department;
	}
	public UserAdmin(int id,String username, String password, String roles, String department) {
		super(id,username,password,roles);
		this.department=department;
	}

	
	private String department;
}
