package com.cropdeal.orderservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cropdeal.orderservice.dto.DealerDetailDto;


@FeignClient("USER-SERVICE")
public interface DealerInterface {

	@GetMapping("/auth/dealer/get/detail/{dealerId}")
	public ResponseEntity<DealerDetailDto> getDealerDetails(@PathVariable int dealerId);
}
