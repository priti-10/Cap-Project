package com.cropdeal.cropservice.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cropdeal.cropservice.dto.CalculateDto;
import com.cropdeal.cropservice.model.CropEntity;
import com.cropdeal.cropservice.model.FarmerOffer;
import com.cropdeal.cropservice.repository.FarmerOfferRepo;

@ExtendWith(MockitoExtension.class)
class FarmerOfferServiceTest {

//	@Test
//	void testFarmerOfferService() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testAddOffer() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetFarmerOffer() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetAllFramerOffersById() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testUpdateFarmerCropEntity() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testUpdateFarmerOffer() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testDeleteFramerOfferById() {
//		fail("Not yet implemented");
//	}

	@Mock
	private FarmerOfferRepo farmerOfferRepo;
	
	@InjectMocks
	private FarmerOfferService farmerOfferService;
	
	
	@Test
	void testCalculateTotal() {
	
		Optional<FarmerOffer> fo=Optional.of(new FarmerOffer(1, 0, 200, 50,null,null,null,null, null));
		Optional<FarmerOffer> fo2=Optional.ofNullable(new FarmerOffer(2, 0, 300, 40,null,null,null,null, null));
		Optional<FarmerOffer> fo3=Optional.ofNullable(new FarmerOffer(2, 0, 400, 30,null, null,null,null,null));
		Map<Integer,Double> offerIdAndKilo=new HashMap<>();
		CalculateDto calculateDto=CalculateDto.builder().offerIdAndKilo(offerIdAndKilo).build();
		offerIdAndKilo.put(1,5.0);
		offerIdAndKilo.put(2,2.0);
		offerIdAndKilo.put(3,1.0);
		when(farmerOfferRepo.findById(1)).thenReturn(fo);
		when(farmerOfferRepo.findById(2)).thenReturn(fo2);
		when(farmerOfferRepo.findById(3)).thenReturn(fo3);
		assertEquals(2000.0, farmerOfferService.calculateTotal(calculateDto));
	}
	
	@Test
	void testGetCropOrderWithNameList() {
		CropEntity cropEntity=new CropEntity(1, "crop", null, null);
		Optional<FarmerOffer> fo=Optional.of(new FarmerOffer(1, 0, 200, 50,null, null,null, null,cropEntity));
		Map<Integer,Double> offerIdAndKilo=new HashMap<>();
		CalculateDto calculateDto=CalculateDto.builder().offerIdAndKilo(offerIdAndKilo).build();
		offerIdAndKilo.put(1,5.0);
		when(farmerOfferRepo.findById(1)).thenReturn(fo);
		assertEquals(1000, farmerOfferService.getCropOrderWithNameList(calculateDto).get("crop"));
	}

}
