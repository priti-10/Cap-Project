package com.example.userservice.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import javax.crypto.SecretKey;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.example.userservice.exception.ApiRequestException;
import com.example.userservice.exception.InvalidTokenException;
import com.example.userservice.exception.JwtAuthenticationException;
import com.example.userservice.exception.TokenExpiredException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;

@Service
public class JwtService {

	private String secretKey="MWB1e7n+YZ0vnwa2oxYQnEYWviDb68258/tpl+SOpJM=";
	
	private MyUserDetailsService userService;
	
	
public JwtService(MyUserDetailsService userService) {
		super();
		this.userService = userService;
	}

//	public JWTService() {
//		try {
//			KeyGenerator keyGen= KeyGenerator.getInstance("HmacSHA256");
//			SecretKey sk=keyGen.generateKey();
//			secretKey = Base64.getEncoder().encodeToString(sk.getEncoded());
//			System.out.println(secretKey);
//		} catch (NoSuchAlgorithmException e) {
//			
////			e.printStackTrace();
//			throw new RuntimeException(e);
//		}
//	}
	
	public String generateToken(String username) {
		
		Map<String,Object> claims=new HashMap<>();
		
		UserDetails user=userService.loadUserByUsername(username);
		
		return Jwts.builder()
				.claim("roles",user.getAuthorities().stream()
						.map(GrantedAuthority::getAuthority)
						.toList())
				.claims()
				.add(claims)
				.subject(username)
				.issuedAt(new Date(System.currentTimeMillis()))
				.expiration(new Date(System.currentTimeMillis()+1000*60*10))
				.and()
				.signWith(getKey())
				.compact();
		

	}

	private SecretKey getKey() {

		byte[] keyBytes= Decoders.BASE64.decode(secretKey);
		return Keys.hmacShaKeyFor(keyBytes);
	}

	@SuppressWarnings("unchecked")
	public List<String> getRolesFromToken(String token){
		Claims claims=extractAllClaims(token);
		return claims.get("roles",List.class);
	}
	
	public String extractUserName(String token) throws ApiRequestException {
		
		return extractClaim(token, Claims::getSubject);
	}

	private <T> T extractClaim(String token, Function<Claims,T> claimResolver) throws ApiRequestException {
		final Claims claims= extractAllClaims(token);
		return claimResolver.apply(claims);
	}

	private Claims extractAllClaims(String token) throws ApiRequestException {
		try {
		return Jwts.parser()
				.verifyWith(getKey())
				.build()
				.parseSignedClaims(token)
				.getPayload();
		}catch(ExpiredJwtException e) {
			throw new TokenExpiredException("JWT Token has expired");
		}catch(SignatureException e) {
			 throw new InvalidTokenException("Invalid JWT signature");
		}catch (MalformedJwtException e) {
            throw new InvalidTokenException("Malformed JWT token");
        } catch (UnsupportedJwtException e) {
            throw new InvalidTokenException("JWT token is not supported");
        } catch (IllegalArgumentException e) {
            throw new JwtAuthenticationException("JWT claims string is empty");
        }
	}

//	public boolean validateToken(String token, UserDetails userDetails) {
//		final String userName= extractUserName(token);
//		return (userName.equals(userDetails.getUsername()) && !isTokenExpired(token));
//	}
	
	public boolean validateToken(String token) {
		
		return !isTokenExpired(token);
	}

	private boolean isTokenExpired(String token) {
		
		return extractExpiration(token).before(new Date());
	}

	private Date extractExpiration(String token) {
		
		return extractClaim(token, Claims::getExpiration);
	}

}
