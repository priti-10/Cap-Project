package com.example.userservice.controller;


import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.userservice.model.UserAdmin;
import com.example.userservice.repository.UsersRepo;
import com.example.userservice.service.JwtService;
import com.example.userservice.service.UsersService;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(controllers = AdminController.class)
@AutoConfigureMockMvc(addFilters = false)
@ExtendWith(MockitoExtension.class)
class AdminControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@MockitoBean
	private UsersService usersService;
	
	@MockitoBean
	private JwtService jwtService;
	
	@MockitoBean
	private UsersRepo usersRepo;
	
	@MockitoBean
	AuthenticationManager authmanager;
	
	@MockitoBean
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private AdminController adminController;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@Test
	void addAdminTest() throws Exception {
		UserAdmin user=new UserAdmin(1,"krishna","k@123","ADMIN","Dev");
		UserAdmin user1=new UserAdmin(1,"krishna","k@1234","ADMIN","Dev");
		
		
		when(usersService.addUser(any(UserAdmin.class))).thenReturn(user1);
		
		assertThat(adminController.addAdmin(user).getBody().getUsername()).isEqualTo(user.getUsername());
		
		this.mockMvc.perform(post("/admin/register")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(user1)))
				.andDo(print())
				.andExpect(status().isOk());
		
	}

}
