package com.order.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.order.entities.Order;

public interface OrderRepository extends JpaRepository<Order, Integer>{
	 List<Order> findByBuyerId(int buyerId); // Custom method to find orders by buyer ID
	 List<Order> findByFarmerId(int farmerId); // Custom method to find orders by farmer ID

}
