package com.user.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

public class Crop {
	
	private int cropId;
	private String cropName;
	private int farmerId;
	private String farmerName;
	private int quantityInKg;
	private double pricePerKg;
	private String status;	// Available, Sold, Pending
	
	public Crop() {
		super();
		
	}
	public Crop(int farmerId, String farmerName, int cropId, String cropName, int quantityInKg, double pricePerKg) {
		super();
		this.farmerId = farmerId;
		this.farmerName = farmerName;
		this.cropId = cropId;
		this.cropName = cropName;
		this.quantityInKg = quantityInKg;
		this.pricePerKg = pricePerKg;
		this.status = "Available";
	}
	
	public int getCropId() {
		return cropId;
	}
	public void setCropId(int cropId) {
		this.cropId = cropId;
	}
	public String getCropName() {
		return cropName;
	}
	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	public int getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}
	public String getFarmerName() {
		return farmerName;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public int getQuantityInKg() {
		return quantityInKg;
	}
	public void setQuantityInKg(int quantityInKg) {
		this.quantityInKg = quantityInKg;
	}
	public double getPricePerKg() {
		return pricePerKg;
	}
	public void setPricePerKg(double pricePerKg) {
		this.pricePerKg = pricePerKg;
	}
	
}
