package com.cropdeal.orderservice.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cropdeal.orderservice.dto.CartDto;
import com.cropdeal.orderservice.dto.StripeResponse;
import com.cropdeal.orderservice.feign.CropCategoryInterface;
import com.cropdeal.orderservice.model.CropCategory;
import com.cropdeal.orderservice.model.CropEntity;
import com.cropdeal.orderservice.model.DealerCart;
import com.cropdeal.orderservice.model.FarmerOffer;
import com.cropdeal.orderservice.model.OrderEntity;
import com.cropdeal.orderservice.service.CartService;
import com.cropdeal.orderservice.service.OrderService;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@RequestMapping("/order")
public class OrderController {

	private CropCategoryInterface categoryInterface;
	private CartService cartService;
	private OrderService orderService;

	public OrderController(CropCategoryInterface categoryInterface, CartService cartService,
			OrderService orderService) {
		super();
		this.categoryInterface = categoryInterface;
		this.cartService = cartService;
		this.orderService = orderService;
	}


	/*
	 * Order APIs EndPoints
	 * 
	 * */
	
	@GetMapping("/confirm/{cartId}")
	public ResponseEntity<StripeResponse> confirmOrder(@PathVariable int cartId) {
		
		return orderService.confirmOrder(cartId);
	}
	
	@GetMapping("/addorder")
	public String addOrder() {
		return orderService.addOrder();
	}
	
	@DeleteMapping("/delete/order/{orderId}")
	public OrderEntity deleteOrder(@PathVariable int orderId) {
		return orderService.deleteOrderEntity(orderId);
	}
	
	@GetMapping("/get/order/{orderId}")
	public OrderEntity getOrder(@PathVariable int orderId) {
		return orderService.getOrderEntity(orderId);
	}

	/*
	 * Search APIs EndPoints
	 * 
	 * */
	@GetMapping("/getall/category")
	public List<CropCategory> getAllCategories(){
		return categoryInterface.getAllCategory();
	}
	
	@GetMapping("/get/category/{categoryId}")
	public CropCategory getCategory(@PathVariable int categoryId) {
		return categoryInterface.getCropCategory(categoryId);
	}
	
	@GetMapping("/getall/crop")
	public List<CropEntity> getAllCategory(){
		return categoryInterface.getAllCropEntity();
	}
	
	@GetMapping("/get/crop/{cropId}")
	public CropEntity getCrop(@PathVariable int cropId) {
		return categoryInterface.getCropEntity(cropId);
	}
	
	@GetMapping("/getalloffers/farmerid/{farmerid}")
	public List<FarmerOffer> getAllFramerOffersById(@PathVariable int farmerid) {
		return categoryInterface.getAllFramerOffersById(farmerid);
	}
	
	@GetMapping("/get/cropbystate/{state}")
	public List<FarmerOffer> getCropByState(@PathVariable String state){
		return categoryInterface.getCropByState(state);
	}
	
	@GetMapping("/get/cropbycity/{city}")
	public List<FarmerOffer> getCropByCity(@PathVariable String city){
		return categoryInterface.getCropByCity(city);
	}
	
	/*
	 * Cart APIs EndPoints
	 * */
	@PostMapping("/cart")
	public DealerCart addDealerCart(@RequestBody DealerCart dealerCart) {
		
		return cartService.addDealerCart(dealerCart);
	}
	
	@GetMapping("/get/dealercart/{cartId}")
	public CartDto getDealerCart(@PathVariable int cartId) {

		return cartService.getDealerCartDto(cartId);
//		return cartService.getDealerCart(cartId);
	}
	
	@PutMapping("/update/dealercart/{cartId}")
	public DealerCart updateDealerCart(@PathVariable int cartId, @RequestBody DealerCart dealerCart) {
		
		return cartService.updateDealerCart(cartId,dealerCart);
	}
	
	@DeleteMapping("/delete/dealercart/{cartId}")
	public DealerCart deleteDealerCart(@PathVariable int cartId) {
		return cartService.deleteDealerCart(cartId);
	}
	
	
}
