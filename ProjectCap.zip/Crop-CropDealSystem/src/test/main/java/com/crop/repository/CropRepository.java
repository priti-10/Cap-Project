package com.crop.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.crop.entities.Crop;

public interface CropRepository extends JpaRepository<Crop,Integer>{
	List<Crop> findByFarmerId(int farmerId);

}
