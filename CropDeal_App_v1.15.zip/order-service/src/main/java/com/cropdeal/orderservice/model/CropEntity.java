package com.cropdeal.orderservice.model;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CropEntity {

	private int cropId;
	private String cropName;
	@JsonIgnoreProperties("farmerCropEntity")
	private List<FarmerOffer> farmerOffer;
	
	@JsonIgnoreProperties("cropList")
	private CropCategory cropCategory;
}
