package com.cropdeal.orderservice.feign;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cropdeal.orderservice.dto.CalculateDto;
import com.cropdeal.orderservice.dto.FarmerDetailDto;
import com.cropdeal.orderservice.dto.VolumeDto;
import com.cropdeal.orderservice.model.CropCategory;
import com.cropdeal.orderservice.model.CropEntity;
import com.cropdeal.orderservice.model.FarmerOffer;

@FeignClient("CROP-SERVICE")
public interface CropCategoryInterface {

	@GetMapping("/crop/getall/category")
	public List<CropCategory> getAllCategory();
	
	@GetMapping("/crop/get/categoryid/{id}")
	public CropCategory getCropCategory(@PathVariable int id);
	
	@GetMapping("/crop/get/cropid/{cropId}")
	public CropEntity getCropEntity(@PathVariable int cropId);
	
	@GetMapping("/crop/getall/crop")
	public List<CropEntity> getAllCropEntity();
	
	@PostMapping("/crop/farmer/get/total")
	public double calculateTotal(@RequestBody CalculateDto calculateDto);
	
	@PostMapping("/crop/farmer/get/totalforeach")
	public Map<String,Double> getCropOrderWithNameList(@RequestBody CalculateDto calculateDto);
	
	@PostMapping("/crop/farmer/get/availability")
	public boolean checkAvailabilityOfCropVolume(@RequestBody VolumeDto volumeDto);
	
	@PostMapping("/crop/farmer/set/availability")
	public boolean setAvailabilityOfCropVolume(@RequestBody VolumeDto volumeDto);
	
	@PostMapping("/crop/farmer/set/volumetodb")
	public boolean setCropVolumeBackToDB(@RequestBody VolumeDto volumeDto);

	@GetMapping("/crop/farmer/get/cropbystate/{state}")
	public List<FarmerOffer> getCropByState(@PathVariable String state);
	
	@GetMapping("/crop/farmer/get/cropbycity/{city}")
	public List<FarmerOffer> getCropByCity(@PathVariable String city);
	
	@GetMapping("/crop/farmer/getall/farmerid/{farmerid}")
	public List<FarmerOffer> getAllFramerOffersById(@PathVariable int farmerid);
	
	@PostMapping("/crop/farmer/get/farmerdetails")
	public List<FarmerDetailDto> getFarmerDetailsForDealer(@RequestBody CalculateDto calculateDto);
}
