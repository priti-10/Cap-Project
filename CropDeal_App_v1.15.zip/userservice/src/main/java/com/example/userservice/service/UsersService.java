package com.example.userservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.userservice.dto.DealerDetailDto;
import com.example.userservice.dto.FarmerDetailDto;
import com.example.userservice.dto.UserDto;
import com.example.userservice.exception.ApiRequestException;
import com.example.userservice.model.UserAdmin;
import com.example.userservice.model.UserDealer;
import com.example.userservice.model.UserFarmer;
import com.example.userservice.model.Users;
import com.example.userservice.repository.UsersRepo;

@Service
public class UsersService {

	private UsersRepo usersRepo;
	private String exceptionMessage = "User not found with Id:";
	private JwtService jwtService;
	AuthenticationManager authmanager;
	private PasswordEncoder passwordEncoder;
	
	public UsersService(UsersRepo usersRepo, JwtService jwtService, AuthenticationManager authmanager,
			PasswordEncoder passwordEncoder) {
		super();
		this.usersRepo = usersRepo;
		this.jwtService = jwtService;
		this.authmanager = authmanager;
		this.passwordEncoder = passwordEncoder;
	}

	

	public Users addUser(Users userNew) {
		if (usersRepo.existsByUsername(userNew.getUsername())) {
			throw new ApiRequestException("Username is already taken! Try Again!");
		}

		userNew.setPassword(passwordEncoder.encode(userNew.getPassword()));

		return usersRepo.save(userNew);
	}

	public String verify(UserDto userDto) {

		try {
			Authentication authentication = authmanager.authenticate(
					new UsernamePasswordAuthenticationToken(userDto.getUsername(), userDto.getPassword()));

			if (authentication.isAuthenticated()) {
				return jwtService.generateToken(userDto.getUsername());
			}
		} catch (BadCredentialsException e) {
			throw new ApiRequestException("Invalid Login or Incorrect Username " + userDto.getUsername());
		}

		return "Not Authenticated";
	}

	public List<Users> getAllUsers() {
		return usersRepo.findAll();
	}

	public Users getProfile(String username) {
		if(!usersRepo.existsByUsername(username))
		{
			throw new ApiRequestException("No UserName with " + username);
		}
		return usersRepo.findByUsername(username);
	}

	public UserAdmin updateAdminProfile(UserAdmin user, int id) {
		Optional<Users> current = usersRepo.findById(id);
		UserAdmin foundUser = null;
		if (current.isEmpty()) {
			throw new ApiRequestException(exceptionMessage + id);
		}
		foundUser = (UserAdmin) current.get();
		foundUser.setUsername(user.getUsername().isBlank() ? foundUser.getUsername() : user.getUsername());
		foundUser.setDepartment(user.getDepartment().isBlank() ? foundUser.getDepartment() : user.getDepartment());
		foundUser.setRoles(user.getRoles().isBlank() ? foundUser.getRoles() : user.getRoles());
		foundUser.setPassword(user.getPassword().isBlank() ? foundUser.getPassword() : user.getPassword());
		return usersRepo.save(foundUser);
	}

	public UserDealer updateDealerProfile(UserDealer user, int id) {
		Optional<Users> current = usersRepo.findById(id);
		UserDealer foundUser = null;
		if (current.isEmpty()) {
			throw new ApiRequestException(exceptionMessage + id);
		}
		foundUser = (UserDealer) current.get();
		foundUser.setUsername(user.getUsername().isBlank() ? foundUser.getUsername() : user.getUsername());
		foundUser.setPassword(user.getPassword().isBlank() ? foundUser.getPassword() : user.getPassword());
		foundUser.setEmail(user.getEmail().isEmpty() ? foundUser.getEmail() : user.getEmail());
		foundUser.setPhoneNumber(user.getPhoneNumber().isBlank() ? foundUser.getPhoneNumber() : user.getPhoneNumber());
		foundUser.setAddress(user.getAddress().isEmpty() ? foundUser.getAddress() : user.getAddress());
		foundUser.setCity(user.getCity().isEmpty() ? foundUser.getCity() : user.getCity());
		foundUser.setState(user.getState().isEmpty() ? foundUser.getState() : user.getState());
		foundUser.setGstNumber(user.getGstNumber().isEmpty() ? foundUser.getGstNumber() : user.getGstNumber());
		foundUser.setBusinessName(
				user.getBusinessName().isEmpty() ? foundUser.getBusinessName() : user.getBusinessName());
		foundUser.setBankAccountNumber(
				user.getBankAccountNumber().isEmpty() ? foundUser.getBankAccountNumber() : user.getBankAccountNumber());
		foundUser.setIfscCode(user.getIfscCode().isEmpty() ? foundUser.getIfscCode() : user.getIfscCode());
		foundUser.setUpiId(user.getUpiId().isEmpty() ? foundUser.getUpiId() : user.getUpiId());
		return usersRepo.save(foundUser);
	}

	public UserFarmer updateFarmerProfile(UserFarmer user, int id) {
		Optional<Users> current = usersRepo.findById(id);
		UserFarmer foundUser = null;
		if (current.isEmpty()) {
			throw new ApiRequestException("User not found with Id:" + id);
		}
		foundUser = (UserFarmer) current.get();
		foundUser.setUsername(user.getUsername().isBlank() ? foundUser.getUsername() : user.getUsername());
		foundUser.setPassword(user.getPassword().isBlank() ? foundUser.getPassword() : user.getPassword());
		foundUser.setEmail(user.getEmail().isEmpty() ? foundUser.getEmail() : user.getEmail());
		foundUser.setPhoneNumber(user.getPhoneNumber().isBlank() ? foundUser.getPhoneNumber() : user.getPhoneNumber());
		foundUser.setAddress(user.getAddress().isEmpty() ? foundUser.getAddress() : user.getAddress());
		foundUser.setCity(user.getCity().isEmpty() ? foundUser.getCity() : user.getCity());
		foundUser.setState(user.getState().isEmpty() ? foundUser.getState() : user.getState());
		foundUser.setCropTypes(user.getCropTypes().isEmpty() ? foundUser.getCropTypes() : user.getCropTypes());
		foundUser.setBankAccountNumber(
				user.getBankAccountNumber().isEmpty() ? foundUser.getBankAccountNumber() : user.getBankAccountNumber());
		foundUser.setIfscCode(user.getIfscCode().isEmpty() ? foundUser.getIfscCode() : user.getIfscCode());
		foundUser.setUpiId(user.getUpiId().isEmpty() ? foundUser.getUpiId() : user.getUpiId());
		return usersRepo.save(foundUser);
	}

	public String deleteProfile(int id) {
		if (!usersRepo.existsById(id)) {
			throw new ApiRequestException(exceptionMessage + id);
		}
		usersRepo.deleteById(id);
		return "Successfully delete!";
	}



	public FarmerDetailDto getFarmerDetails(int farmerId) {
		Optional<Users> userFarmer=usersRepo.findById(farmerId);
		if(userFarmer.isEmpty() || !(userFarmer.get() instanceof UserFarmer)) {
			throw new ApiRequestException(exceptionMessage + farmerId);
		}
		UserFarmer foundFarmer=(UserFarmer) userFarmer.get();
		return FarmerDetailDto.builder()
				.farmerUserId(foundFarmer.getId())
				.username(foundFarmer.getUsername())
				.email(foundFarmer.getEmail())
				.phoneNumber(foundFarmer.getPhoneNumber())
				.city(foundFarmer.getCity())
				.state(foundFarmer.getState())
				.build();
	}



	public DealerDetailDto getDealerDetails(int dealerId) {
		Optional<Users> userDealer=usersRepo.findById(dealerId);
		if(userDealer.isEmpty() || !(userDealer.get() instanceof UserDealer)) {
			throw new ApiRequestException(exceptionMessage + dealerId);
		}
		UserDealer foundDealer=(UserDealer) userDealer.get();
		return DealerDetailDto.builder()
				.dealerUserId(foundDealer.getId())
				.username(foundDealer.getUsername())
				.email(foundDealer.getEmail())
				.phoneNumber(foundDealer.getPhoneNumber())
				.address(foundDealer.getAddress())
				.city(foundDealer.getCity())
				.state(foundDealer.getState())
				.businessName(foundDealer.getBusinessName())
				.build();
	}

}
