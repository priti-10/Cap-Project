package com.crop.service;

import java.util.List;


import com.crop.entities.Crop;

public interface CropService {
	Crop add (Crop crop);
	String delete(int cropId);
	Crop getCropById(int cropId);
	List<Crop> getAllCrops();
	public Crop updateCrop(Crop updatedCrop);
	
	
	

}


//package com.user.service;
//
//import java.util.List;
//
//import com.user.entities.User;
//
//public interface UserService {
//	
//	User add(User user);
//	String delete(int userId);
//	List<User> getUserByRole (String role);
//	User getUserById(int userId);
//	List<User> getUsers();
//
//}
