package com.cropdeal.cropservice.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Map.Entry;

import org.springframework.stereotype.Service;

import com.cropdeal.cropservice.dto.CalculateDto;
import com.cropdeal.cropservice.dto.FarmerDetailDto;
import com.cropdeal.cropservice.dto.FarmerDto;
import com.cropdeal.cropservice.dto.VolumeDto;
import com.cropdeal.cropservice.exception.ApiRequestException;
import com.cropdeal.cropservice.feign.FarmerInteface;
import com.cropdeal.cropservice.model.CropEntity;
import com.cropdeal.cropservice.model.FarmerOffer;
import com.cropdeal.cropservice.repository.CropEntityRepo;
import com.cropdeal.cropservice.repository.FarmerOfferRepo;

@Service
public class FarmerOfferService {

	private FarmerOfferRepo farmerOfferRepo;
	private CropEntityRepo cropEntityRepo;
	private FarmerInteface farmerInteface;
	private String messageFarmerOfferNotFound = "FarmerOffer not Found! Id: ";


	public FarmerOfferService(FarmerOfferRepo farmerOfferRepo, CropEntityRepo cropEntityRepo,
			FarmerInteface farmerInteface) {
		super();
		this.farmerOfferRepo = farmerOfferRepo;
		this.cropEntityRepo = cropEntityRepo;
		this.farmerInteface = farmerInteface;
	}

	public FarmerOffer addOffer(int cropId, FarmerOffer farmerOffer) {
		try {
			Optional<CropEntity> cropEntity = cropEntityRepo.findById(cropId);
			if (cropEntity.isPresent()) {
				farmerOffer.setFarmerCropEntity(cropEntity.get());
				FarmerDetailDto detailDto=farmerInteface.getFarmerDetails(farmerOffer.getFarmerId()).getBody();
				if(detailDto==null) {
					throw new ApiRequestException("Invalid FarmerId"+farmerOffer.getFarmerId());
				}
				farmerOffer.setEmail(detailDto.getEmail().isEmpty()
						?farmerOffer.getEmail():detailDto.getEmail());
				farmerOffer.setCity(detailDto.getCity().isEmpty()
						?farmerOffer.getCity():detailDto.getCity());
				farmerOffer.setPhoneNumber(detailDto.getPhoneNumber().isEmpty()
						?farmerOffer.getPhoneNumber():detailDto.getPhoneNumber());
				farmerOffer.setState(detailDto.getState().isEmpty()
						?farmerOffer.getState():detailDto.getState());
				
				return farmerOfferRepo.save(farmerOffer);
			} else {
				throw new ApiRequestException("CropEntity not Found!"+cropId);
			}
		}catch (IllegalArgumentException e) {
			throw new ApiRequestException("Empty Data or IllegalArgument!");
		}
	}

	public FarmerOffer getFarmerOffer(int farmerOfferId) {
		Optional<FarmerOffer> foundOffer = farmerOfferRepo.findById(farmerOfferId);
		if (foundOffer.isEmpty()) {
			throw new ApiRequestException(messageFarmerOfferNotFound+farmerOfferId);
		}
		return foundOffer.get();
	}

	public List<FarmerOffer> getAllFramerOffersById(int farmerid) {
		if (farmerOfferRepo.findAllByFarmerId(farmerid).isEmpty()) {
			throw new ApiRequestException("No Offer Added by FarmerId " + farmerid + " !");
		}
		return farmerOfferRepo.findAllByFarmerId(farmerid);
	}

	public FarmerOffer updateFarmerCropEntity(FarmerDto farmerDto) {
		Optional<FarmerOffer> foundOffer = farmerOfferRepo.findById(farmerDto.getFarmerOfferId());
		if (foundOffer.isPresent()) {
			Optional<CropEntity> updateCrop = cropEntityRepo.findById(farmerDto.getCropId());
			if (updateCrop.isPresent()) {
				foundOffer.get().setFarmerCropEntity(updateCrop.get());
				return farmerOfferRepo.save(foundOffer.get());
			} else {
				throw new ApiRequestException("CropEntity Not Found!"+farmerDto.getCropId());
			}
		} else {
			throw new ApiRequestException(messageFarmerOfferNotFound+farmerDto.getFarmerOfferId());
		}

	}

	public FarmerOffer updateFarmerOffer(int farmerOfferId, FarmerOffer updatedOffer) {
		Optional<FarmerOffer> foundOffer = farmerOfferRepo.findById(farmerOfferId);
		if (foundOffer.isPresent()) {
			foundOffer.get().setFarmerId(
					(updatedOffer.getFarmerId() != 0) ? updatedOffer.getFarmerId() : foundOffer.get().getFarmerId());
			foundOffer.get().setPerKiloPrice((updatedOffer.getPerKiloPrice() != 0) ? updatedOffer.getPerKiloPrice()
					: foundOffer.get().getPerKiloPrice());
			foundOffer.get().setTotalCapacity((updatedOffer.getTotalCapacity() != 0) ? updatedOffer.getTotalCapacity()
					: foundOffer.get().getTotalCapacity());
			return farmerOfferRepo.save(foundOffer.get());
		} else {
			throw new ApiRequestException(messageFarmerOfferNotFound+farmerOfferId);
		}

	}

	public FarmerOffer deleteFramerOfferById(int farmerOfferId) {
		Optional<FarmerOffer> foundOffer = farmerOfferRepo.findById(farmerOfferId);
		if (foundOffer.isPresent()) {
			farmerOfferRepo.delete(foundOffer.get());
			return foundOffer.get();
		} else {
			throw new ApiRequestException(messageFarmerOfferNotFound+farmerOfferId);
		}

	}

	public boolean checkAvailabilityOfCropVolume(VolumeDto volumeDto) {
		Optional<FarmerOffer> foundOffer = farmerOfferRepo.findById(volumeDto.getOfferId());
		if (foundOffer.isEmpty()) {
			throw new ApiRequestException(messageFarmerOfferNotFound+volumeDto.getOfferId());
		}

		return (volumeDto.getCropVolume() <= foundOffer.get().getTotalCapacity() && volumeDto.getCropVolume() >= 0);
	}
	
	public boolean setAvailabilityOfCropVolume(VolumeDto volumeDto) {
		Optional<FarmerOffer> foundOffer = farmerOfferRepo.findById(volumeDto.getOfferId());
		if (foundOffer.isEmpty()) {
			throw new ApiRequestException(messageFarmerOfferNotFound+volumeDto.getOfferId());
		}
		foundOffer.get().setTotalCapacity(foundOffer.get().getTotalCapacity()-volumeDto.getCropVolume());
		farmerOfferRepo.save(foundOffer.get());
		return true;
	}
	
	public boolean setCropVolumeBackToDB(VolumeDto volumeDto) {
		Optional<FarmerOffer> foundOffer = farmerOfferRepo.findById(volumeDto.getOfferId());
		if (foundOffer.isEmpty()) {
			throw new ApiRequestException(messageFarmerOfferNotFound+volumeDto.getOfferId());
		}
		foundOffer.get().setTotalCapacity(foundOffer.get().getTotalCapacity()+volumeDto.getCropVolume());
		farmerOfferRepo.save(foundOffer.get());
		return true;
	}

	public double calculateTotal(CalculateDto calculateDto) {
		double total = 0;
		for (Entry<Integer, Double> e : calculateDto.getOfferIdAndKilo().entrySet()) {
			Optional<FarmerOffer> foundOffer = farmerOfferRepo.findById(e.getKey());
			if (foundOffer.isEmpty()) {
				throw new ApiRequestException(messageFarmerOfferNotFound+e.getKey());
			}
			int price = foundOffer.get().getPerKiloPrice();
			total += price * e.getValue();
		}
		return total;
	}

	public List<FarmerDetailDto> getFarmerDetailsForDealer(CalculateDto calculateDto){
			List<FarmerDetailDto> farmerDetailsList=new ArrayList<>();
			for (Entry<Integer, Double> e : calculateDto.getOfferIdAndKilo().entrySet()) {
				Optional<FarmerOffer> foundOffer = farmerOfferRepo.findById(e.getKey());
				if (foundOffer.isEmpty()) {
					throw new ApiRequestException(messageFarmerOfferNotFound+e.getKey());
				}
				FarmerDetailDto farmerDetailDto=farmerInteface.getFarmerDetails(foundOffer.get().getFarmerId()).getBody();
				if(farmerDetailDto==null) {
					throw new ApiRequestException("Invalid FarmerId"+foundOffer.get().getFarmerId());
				}
				if(farmerDetailsList.contains(farmerDetailDto))
					continue;
				farmerDetailsList.add(farmerDetailDto);
			}
			return farmerDetailsList;
		}

	public Map<String, Double> getCropOrderWithNameList(CalculateDto calculateDto) {
		Map<String, Double> cropOrderList = new HashMap<>();
		for (Entry<Integer, Double> e : calculateDto.getOfferIdAndKilo().entrySet()) {
			Optional<FarmerOffer> foundOffer = farmerOfferRepo.findById(e.getKey());
			if (foundOffer.isEmpty()) {
				throw new ApiRequestException(messageFarmerOfferNotFound+e.getKey());
			}
			int price = foundOffer.get().getPerKiloPrice();
			String cropName = foundOffer.get().getFarmerCropEntity().getCropName();
			double totalForEach = price * e.getValue();
			cropOrderList.put(cropName, totalForEach);
		}
		return cropOrderList;
	}

	public List<FarmerOffer> getCropByState(String state) {
		return farmerOfferRepo.findAllByState(state);
	}

	public List<FarmerOffer> getCropByCity(String city) {
		return farmerOfferRepo.findAllByCity(city);
	}

	

	

}
