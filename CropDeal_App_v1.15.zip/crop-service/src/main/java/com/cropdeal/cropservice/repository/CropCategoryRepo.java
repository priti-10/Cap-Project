package com.cropdeal.cropservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cropdeal.cropservice.model.CropCategory;

@Repository
public interface CropCategoryRepo extends JpaRepository<CropCategory, Integer>{

}
