package com.cropdeal.orderservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cropdeal.orderservice.model.DealerCart;

@Repository
public interface CartRepo extends JpaRepository<DealerCart, Integer>{

	DealerCart findByDealerId(int dealerId);

}
