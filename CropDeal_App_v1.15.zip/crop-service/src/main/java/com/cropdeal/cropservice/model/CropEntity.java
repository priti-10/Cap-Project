package com.cropdeal.cropservice.model;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class CropEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cropId;
	private String cropName;
	@OneToMany(mappedBy = "farmerCropEntity",cascade = CascadeType.ALL)
	@JsonIgnoreProperties("farmerCropEntity")
	private List<FarmerOffer> farmerOffer;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "category_id")
	@JsonIgnoreProperties("cropList")
	private CropCategory cropCategory;
}
