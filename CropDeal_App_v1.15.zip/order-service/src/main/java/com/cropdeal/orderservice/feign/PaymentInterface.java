package com.cropdeal.orderservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cropdeal.orderservice.dto.ProductRequest;
import com.cropdeal.orderservice.dto.StripeResponse;


@FeignClient("PAYMENT-GATEWAY")
public interface PaymentInterface {

	 @PostMapping("/payment/checkout")
	    public ResponseEntity<StripeResponse> checkoutProducts(@RequestBody ProductRequest productRequest);
}
