package com.crop.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.crop.Controller.crop;
import com.crop.entities.Crop;
import com.crop.repository.CropRepository;
import java.util.Optional; 

@Service
public class CropServiceImpl {

	@Autowired
	private CropRepository cropRepository;
	
	public List<Crop> getAllCrops(){
		return cropRepository.findAll();
	}
	
	public Crop getCropById(int cropId) {
		Optional<Crop> crop = cropRepository.findById(cropId);
		return crop.orElse(null);
	}
	
	public List<Crop> getCropsByFarmer(int farmerId) {
        return cropRepository.findByFarmerId(farmerId);
    }
	
	public Crop addCrop(Crop crop) {
        return cropRepository.save(crop);
    }
	
	// Update an existing crop
    public Crop updateCrop(Crop updatedCrop) {
    	
    	return addCrop(updatedCrop);
        //Optional<Crop> existingCrop = cropRepository.findById(cropId); // Check if crop exists
//        if (existingCrop.isPresent()) {
//            Crop crop = existingCrop.get();
//            crop.setCropName(updatedCrop.getCropName());
//            crop.setQuantity(updatedCrop.getQuantity());
//            crop.setPrice(updatedCrop.getPrice());
//            //crop.setStatus(updatedCrop.getStatus());
//            return cropRepository.save(crop); // Save the updated crop
//        }
//        return null;
    }

    // Delete a crop by ID
    public String deleteCrop(int cropId) {
        cropRepository.deleteById(cropId);
        return "Crop deleted successfully!";
    }

}
