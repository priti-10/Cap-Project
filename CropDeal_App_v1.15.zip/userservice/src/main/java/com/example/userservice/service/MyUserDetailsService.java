package com.example.userservice.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.userservice.exception.ApiRequestException;
import com.example.userservice.model.UserPrincipal;
import com.example.userservice.model.Users;
import com.example.userservice.repository.UsersRepo;


@Service
public class MyUserDetailsService implements UserDetailsService{

	private UsersRepo usersRepo;

	public MyUserDetailsService(UsersRepo usersRepo) {
		super();
		this.usersRepo = usersRepo;
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Users user=usersRepo.findByUsername(username);
		
		if(user==null) {
			
			throw new ApiRequestException("User not found with username in MyUserDetailsService"+username,new UsernameNotFoundException("User not found"));
		}
		
		return new UserPrincipal(user);
	}

}
