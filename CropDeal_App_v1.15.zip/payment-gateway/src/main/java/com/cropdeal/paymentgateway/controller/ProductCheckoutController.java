package com.cropdeal.paymentgateway.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cropdeal.paymentgateway.dto.ProductRequest;
import com.cropdeal.paymentgateway.dto.StripeResponse;
import com.cropdeal.paymentgateway.feign.OrderInteface;
import com.cropdeal.paymentgateway.service.StripeService;


@RestController
@RequestMapping("/payment")
public class ProductCheckoutController {

	private StripeService stripeService;
	private OrderInteface orderInteface;


    public ProductCheckoutController(StripeService stripeService, OrderInteface orderInteface) {
		super();
		this.stripeService = stripeService;
		this.orderInteface = orderInteface;
	}

	@PostMapping("/checkout")
    public ResponseEntity<StripeResponse> checkoutProducts(@RequestBody ProductRequest productRequest) {
        StripeResponse stripeResponse = stripeService.checkoutProducts(productRequest);
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(stripeResponse);
    }
    
    @GetMapping("/success")
    public String successResponse() {
    	return orderInteface.addOrder();
    }
    
    @GetMapping("/cancel")
    public String cancelResponse() {
    	return "Something went wrong! Please try again!";
    }
}
