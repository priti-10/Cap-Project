package com.example.userservice.configuration;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.context.ApplicationContext;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.userservice.exception.InvalidTokenException;
import com.example.userservice.exception.JwtAuthenticationException;
import com.example.userservice.exception.TokenExpiredException;
import com.example.userservice.service.JwtService;
//import com.example.userservice.service.MyUserDetailsService;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtFilter extends OncePerRequestFilter{

	private JwtService jwtService;
	
	ApplicationContext context;
	
	public JwtFilter(JwtService jwtService, ApplicationContext context) {
		super();
		this.jwtService = jwtService;
		this.context = context;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws  IOException, ServletException {
		//Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJrcmlzaCIsImlhdCI6MTc0MTk2NDk3NiwiZXhwIjoxNzQxOTY1MDg0fQ.t0N6K_4Z_BQ5jjPruJko6eCuMZvhW8yQrHh4H6WYpdQ
		try {
		String authHeader=request.getHeader("Authorization");
		String token=null;
		String username=null;
		
		if(authHeader != null && authHeader.startsWith("Bearer ")) {
			token=authHeader.substring(7);
			username=jwtService.extractUserName(token);
		}
		
		if(username != null && SecurityContextHolder.getContext().getAuthentication()==null) {
//			UserDetails userDetails=context.getBean(MyUserDetailsService.class).loadUserByUsername(username);
			List<GrantedAuthority> authorities=jwtService.getRolesFromToken(token).stream()
															.map(SimpleGrantedAuthority::new)
															.collect(Collectors.toList());
			if(jwtService.validateToken(token)) {
				UsernamePasswordAuthenticationToken authToken= new UsernamePasswordAuthenticationToken(username,null , authorities);
				authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(authToken);
			}
		}
		
		filterChain.doFilter(request, response);
		} catch (TokenExpiredException | InvalidTokenException | JwtAuthenticationException e) {
            handleExceptionTest(response, e.getMessage(), HttpServletResponse.SC_UNAUTHORIZED);
		}  catch (Exception e) {
            handleException(response, "Authentication error", HttpServletResponse.SC_UNAUTHORIZED);
        }
	}

	 private void handleException(HttpServletResponse response, String message, int statusCode) throws IOException {
	        response.setStatus(statusCode);
	        response.setContentType("application/json");
	        response.getWriter().write("{\"error\": \"" + message + "\"}");
	        response.getWriter().flush();
	    }
	 private void handleExceptionTest(HttpServletResponse response, String message, int statusCode) throws IOException {
	        response.setStatus(statusCode);
	        response.setContentType("application/json");
	        ObjectMapper objectMapper = new ObjectMapper();
	        String json = objectMapper.writeValueAsString(Collections.singletonMap("errors", message));
	        response.getWriter().write(json);
	        response.getWriter().flush();
	    }

}
