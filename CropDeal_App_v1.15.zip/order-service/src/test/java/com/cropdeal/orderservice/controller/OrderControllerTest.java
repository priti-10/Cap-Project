package com.cropdeal.orderservice.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.cropdeal.orderservice.feign.CropCategoryInterface;
import com.cropdeal.orderservice.model.DealerCart;
import com.cropdeal.orderservice.service.CartService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest(controllers = OrderController.class)
@AutoConfigureMockMvc
@ExtendWith(MockitoExtension.class)
class OrderControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired 
	private ObjectMapper mapper;
	
	@MockitoBean
	private CartService cartService; 
	
	@MockitoBean
	private CropCategoryInterface categoryInterface;
	

	@Test
	void testAddDealerCart() throws JsonProcessingException, Exception {
		DealerCart cart=DealerCart.builder().dealerId(1).build();
		
		when(cartService.addDealerCart(any(DealerCart.class))).thenReturn(cart);
		mockMvc.perform(MockMvcRequestBuilders.post("/order/cart")
				.contentType(MediaType.APPLICATION_JSON)
				.content(mapper.writeValueAsString(cart)))
		.andExpect(MockMvcResultMatchers.status().isOk());
	}

}
