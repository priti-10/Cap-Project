package com.cropdeal.orderservice.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cropdeal.orderservice.dto.CalculateDto;
import com.cropdeal.orderservice.dto.CartDto;
import com.cropdeal.orderservice.dto.ProductRequest;
import com.cropdeal.orderservice.dto.StripeResponse;
import com.cropdeal.orderservice.exception.ApiRequestException;
import com.cropdeal.orderservice.feign.CropCategoryInterface;
import com.cropdeal.orderservice.feign.PaymentInterface;
import com.cropdeal.orderservice.model.DealerCart;
import com.cropdeal.orderservice.model.OrderEntity;
import com.cropdeal.orderservice.repository.CartRepo;
import com.cropdeal.orderservice.repository.OrderRepo;

@Service
public class OrderService {

	
	private CartRepo cartRepo;
	private CropCategoryInterface categoryInterface;
	private OrderRepo orderRepo;
	private CartService cartService;
	private PaymentInterface paymentInterface;
	
	private int cartId;
	
	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public OrderService(CartRepo cartRepo, CropCategoryInterface categoryInterface, OrderRepo orderRepo,
			CartService cartService, PaymentInterface paymentInterface) {
		super();
		this.cartRepo = cartRepo;
		this.categoryInterface = categoryInterface;
		this.orderRepo = orderRepo;
		this.cartService = cartService;
		this.paymentInterface = paymentInterface;
	}

	public ResponseEntity<StripeResponse> confirmOrder(int cartId) {
		Optional<DealerCart> cart=cartRepo.findById(cartId);
		if(cart.isEmpty()) {
			throw new ApiRequestException("Cart Not Found");
		}
		OrderEntity orderEntity=OrderEntity.builder()
				.createdAt(LocalDateTime.now())
				.totalAmoumt(cartService.calculateTotal(CalculateDto.builder().
				offerIdAndKilo(cart.get().getOfferIdAndKilo())
					.build()))
				.build();
		orderEntity.setDealerCart(cart.get());
		ProductRequest productRequest= ProductRequest.builder()
					.amount((long) (orderEntity.getTotalAmoumt()*100))
					.quantity((long) 1)
					.currency("INR")
					.name("Crops")
					.build();
		setCartId(cartId);
		return paymentInterface.checkoutProducts(productRequest);
	}
	
	public CartDto fillCartDto(DealerCart cart) {
		return CartDto.builder()
				.cartId(cart.getCartId())
				.dealerId(cart.getDealerId())
				.offerIdAndKilo(cart.getOfferIdAndKilo())
				.cropOrderList(categoryInterface.getCropOrderWithNameList(
						CalculateDto.builder().offerIdAndKilo(
								cart.getOfferIdAndKilo()).build()
						))
				
				.totalCost(cartService.calculateTotal(CalculateDto.builder().
				offerIdAndKilo(cart.getOfferIdAndKilo())
					.build()))
				
				.build();
	}
	
	public String addOrder() {
		
		int foundcartId=getCartId();
		Optional<DealerCart> cart=cartRepo.findById(foundcartId);
		if(cart.isEmpty()) {
			throw new ApiRequestException("Cart Not Found");
		}
		OrderEntity orderEntity=OrderEntity.builder()
				.createdAt(LocalDateTime.now())
				.totalAmoumt(cartService.calculateTotal(CalculateDto.builder().
				offerIdAndKilo(cart.get().getOfferIdAndKilo())
					.build()))
				.build();
		orderEntity.setDealerCart(cart.get());
		orderRepo.save(orderEntity);
		return "Success! Your Order is Confirmed";
	}
	public OrderEntity deleteOrderEntity(int orderId) {
		Optional<OrderEntity> foundEntity=orderRepo.findById(orderId);
		if(foundEntity.isEmpty())
			throw new ApiRequestException("Order Not Found");
		orderRepo.delete(foundEntity.get());
		return foundEntity.get();
	}
	
	public OrderEntity getOrderEntity(int orderId) {
		Optional<OrderEntity> foundEntity=orderRepo.findById(orderId);
		if(foundEntity.isEmpty())
			throw new ApiRequestException("Order Not Found with Id:"+orderId);
		return foundEntity.get();
	}

}
