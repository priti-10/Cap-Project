package com.order.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.entities.Order;
import com.order.service.OrderService;
import com.order.service.impl.OrderServiceImpl;

@RestController
@RequestMapping("/orders")
public class OrderController {
	
	@Autowired
	 private OrderServiceImpl service;
	
	@GetMapping("/view") // GET method to fetch all orders
    public List<Order> getAllOrders() {
        return service.getAllOrders();
    }

    @GetMapping("/viewbyid/{orderId}") // GET method to fetch an order by its ID
    public Order getOrderById(@PathVariable int orderId) {
        return service.getOrderById(orderId);
    }

    @GetMapping("/viewbybuyer/{buyerId}") // GET method to fetch all orders by a specific buyer
    public List<Order> getOrdersByBuyer(@PathVariable int buyerId) {
        return service.getOrdersByBuyer(buyerId);
    }

    @GetMapping("/viewbyfarmer/{farmerId}") // GET method to fetch all orders for a specific farmer
    public List<Order> getOrdersByFarmer(@PathVariable int farmerId) {
        return service.getOrdersByFarmer(farmerId);
    }

    @PostMapping("/add") // POST method to add a new order
    public Order addOrder(@RequestBody Order order) {
        return service.addOrder(order);
    }

//    @PutMapping("/update/{orderId}") // PUT method to update an existing order
//    public Order updateOrder(@PathVariable int orderId, @RequestBody Order order) {
//        return service.updateOrder(orderId, order);
//    }

//    @DeleteMapping("/delete/{orderId}") // DELETE method to remove an order by ID
//    public String deleteOrder(@PathVariable int orderId) {
//        return service.deleteOrder(orderId);
//    }

}
