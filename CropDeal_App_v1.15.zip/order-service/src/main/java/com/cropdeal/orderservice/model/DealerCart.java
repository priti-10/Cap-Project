package com.cropdeal.orderservice.model;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class DealerCart {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cartId;
	private int dealerId;
	private String status;
	private LocalDateTime cartCreatedAt;
	private String username;
	private String email;
	private String phoneNumber;
	private String address;
	private String city;
	private String state;
	private String businessName;
	
	
	@ElementCollection(fetch = FetchType.EAGER)
	private Map<Integer,Double> offerIdAndKilo;
	
	@ElementCollection(fetch = FetchType.EAGER)
	private List<Integer> cropOrderedList;

}
