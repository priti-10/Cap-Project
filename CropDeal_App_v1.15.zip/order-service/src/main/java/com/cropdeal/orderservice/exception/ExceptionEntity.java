package com.cropdeal.orderservice.exception;

import java.time.LocalDateTime;

public class ExceptionEntity {

	private final String message;
	private final int httpStatusValue;
	private final String error;
	private final LocalDateTime timestamp;
	public ExceptionEntity(String message, int httpStatusValue,String error, LocalDateTime timestamp) {
		super();
		this.message = message;
		this.httpStatusValue = httpStatusValue;
		this.error=error;
		this.timestamp = timestamp;
	}
	public String getMessage() {
		return message;
	}
	public String getError() {
		return error;
	}
	public int getHttpStatusValue() {
		return httpStatusValue;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	
	
}
