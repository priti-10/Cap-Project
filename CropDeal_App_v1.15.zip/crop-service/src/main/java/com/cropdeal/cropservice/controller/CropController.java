package com.cropdeal.cropservice.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cropdeal.cropservice.dto.CropDto;
import com.cropdeal.cropservice.model.CropCategory;
import com.cropdeal.cropservice.model.CropEntity;
import com.cropdeal.cropservice.service.CropCategoryService;
import com.cropdeal.cropservice.service.CropEntityService;

@RestController
@RequestMapping("/crop")
public class CropController {

	private CropCategoryService cropCategoryService;
	private CropEntityService cropEntityService;
	

	public CropController(CropCategoryService cropCategoryService, CropEntityService cropEntityService) {
		super();
		this.cropCategoryService = cropCategoryService;
		this.cropEntityService = cropEntityService;
	}

	/*
	 * Category APIs end-point
	 * */
	
	@PostMapping("/add/category")
	public CropCategory addCropCategory(@RequestBody CropCategory cropCategory) {
		return cropCategoryService.addCropCategory(cropCategory);
	}
	
	@GetMapping("/get/categoryid/{id}")
	public CropCategory getCropCategory(@PathVariable int id) {
		return cropCategoryService.getCropCategory(id);
	}
	
	@GetMapping("/getall/category")
	public List<CropCategory> getAllCropCategory(){
		return cropCategoryService.getAllCropCategory();
	}
	
	@PutMapping("/update/categoryid/{categoryId}")
	public CropCategory updateCropCategory(@PathVariable int categoryId,@RequestBody CropCategory category) {
		return cropCategoryService.updateCropCategory(categoryId,category);
	}
	
	@DeleteMapping("/delete/categoryid/{categoryId}")
	public CropCategory deleteCropCategory(@PathVariable int categoryId) {
		return cropCategoryService.deleteCropCategory(categoryId);
	}
	
	/*
	 * Crop APIs end-point
	 * */
	
	@PostMapping("/add/crop/{categoryid}")
	public CropEntity addCropEntity(@RequestBody CropEntity cropEntity,@PathVariable int categoryid) {
		
		return cropEntityService.addCropEntity(categoryid,cropEntity);
	}
	
	@GetMapping("/get/cropid/{cropId}")
	public CropEntity getCropEntity(@PathVariable int cropId) {
		return cropEntityService.getCropEntity(cropId);
	}
	
	@GetMapping("/getall/crop")
	public List<CropEntity> getAllCropEntity(){
		return cropEntityService.getAllCropEntity();
	}
	
	@PutMapping("/update/cropid/{cropId}")
	public CropEntity updateCropEntity(@PathVariable int cropId,@RequestBody CropEntity crop) {
		return cropEntityService.updateCropEntity(cropId,crop);
	}
	
	@PutMapping("/update/cropcategory")
	public CropEntity updateCropEntityCategory(@RequestBody CropDto cropDto) {
		return cropEntityService.updateCropEntityCategory(cropDto);
	}
	
	@DeleteMapping("/delete/cropid/{cropId}")
	public CropEntity deleteCropEntity(@PathVariable int cropId) {
		return cropEntityService.deleteCropEntity(cropId);
	}
	
}
