package com.example.userservice.model;

import java.time.LocalDateTime;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true) 
@Entity
@AllArgsConstructor
@NoArgsConstructor
@DiscriminatorValue("DE")
public class UserDealer extends Users{
	
//	@Email(regexp = "[a-z]{5,10}@gmail\\.com")
	private String email;
//	@Pattern(regexp = "\\d{10}",message = "Invalid PhoneNumber!")
	private String phoneNumber;
	private String address;
	private String city;
	private String state;
	private String businessName;
//	@Pattern(regexp = "\\d{5}[A-Z]+")
//	@Pattern(regexp = "[0-9]{1}[0-9]{1}[A-Z]{5}\\d{4}[A-Z]{1}[0-9]{1}[A-Z]{1}[0-9]{1}")
	private String gstNumber;
//	@NotNull(message = "Invalid bankAccountNumber!")
	private String bankAccountNumber;
//	@NotNull(message = "Invalid ifscCode!")
	private String ifscCode;
	private String upiId;
	private LocalDateTime createdDateTime;
	
}
