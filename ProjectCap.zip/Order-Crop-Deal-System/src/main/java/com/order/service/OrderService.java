package com.order.service;

import java.util.List;

import com.order.entities.Order;

public interface OrderService {
	public List<Order> getAllOrders();
	public Order getOrderById(int orderId);
	public List<Order> getOrdersByBuyer(int buyerId);
	 public List<Order> getOrdersByFarmer(int farmerId);
	 public Order addOrder(Order order);
}
