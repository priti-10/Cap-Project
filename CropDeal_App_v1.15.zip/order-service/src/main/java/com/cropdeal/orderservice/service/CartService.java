package com.cropdeal.orderservice.service;

import java.time.LocalDateTime;
import java.util.Map.Entry;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cropdeal.orderservice.dto.CalculateDto;
import com.cropdeal.orderservice.dto.CartDto;
import com.cropdeal.orderservice.dto.DealerDetailDto;
import com.cropdeal.orderservice.dto.VolumeDto;
import com.cropdeal.orderservice.exception.ApiRequestException;
import com.cropdeal.orderservice.feign.CropCategoryInterface;
import com.cropdeal.orderservice.feign.DealerInterface;
import com.cropdeal.orderservice.model.DealerCart;
import com.cropdeal.orderservice.repository.CartRepo;

@Service
public class CartService {

	private CartRepo cartRepo;
	private CropCategoryInterface categoryInterface;
	private DealerInterface dealerInterface; 

	

	public CartService(CartRepo cartRepo, CropCategoryInterface categoryInterface, DealerInterface dealerInterface) {
		super();
		this.cartRepo = cartRepo;
		this.categoryInterface = categoryInterface;
		this.dealerInterface = dealerInterface;
	}

	/*
	 * This method add new cart if cart for that dealerId is not present,
	 * or else it will fetch the cart add to the offerIdAndKilo map.
	 * 
	 * */ 
	public DealerCart addDealerCart(DealerCart dealerCart) {
		
		// If cart already exit with dealerId, item(s) are added to the existing cart
		if(cartRepo.existsById(dealerCart.getDealerId())) {
			dealerCart.setCartCreatedAt(LocalDateTime.now());
			DealerCart foundCart=cartRepo.findByDealerId(dealerCart.getDealerId());
			for(Entry<Integer,Double> e:dealerCart.getOfferIdAndKilo().entrySet()) {
				
				if(checkAvailabilityOfCropVolume(VolumeDto.builder().offerId(e.getKey())
						.cropVolume(e.getValue()).build())) {
					setCropVolumeBackToDB(VolumeDto.builder().offerId(e.getKey())
							.cropVolume(e.getValue()).build());
					throw new ApiRequestException("cropvolume is invalid/insufficent cropvolume");
				}
				
				setAvailabilityOfCropVolume(VolumeDto.builder().offerId(e.getKey())
						.cropVolume(e.getValue()).build());
				
				foundCart.getOfferIdAndKilo().put(e.getKey(), e.getValue());
			}
			return updateDealerCart(foundCart.getCartId(), foundCart);
		}
		
		//if not, create new cart
		DealerDetailDto dealerDeatailDto= dealerInterface.getDealerDetails(dealerCart.getDealerId()).getBody();
		if(dealerDeatailDto==null) {
			throw new ApiRequestException("No dealer with Id"+dealerCart.getCartId());
		}
		dealerCart=addDealerDetails(dealerCart,dealerDeatailDto);
		dealerCart.setCartCreatedAt(LocalDateTime.now());
		for(Entry<Integer,Double> e:dealerCart.getOfferIdAndKilo().entrySet()) {
		if(!checkAvailabilityOfCropVolume(VolumeDto.builder().offerId(e.getKey())
				.cropVolume(e.getValue()).build())) {
			setCropVolumeBackToDB(VolumeDto.builder().offerId(e.getKey())
					.cropVolume(e.getValue()).build());
			throw new ApiRequestException("cropvolume is invalid");
		}
		
		setAvailabilityOfCropVolume(VolumeDto.builder().offerId(e.getKey())
				.cropVolume(e.getValue()).build());
		}
		return cartRepo.save(dealerCart);
	}

	public DealerCart addDealerDetails(DealerCart dealerCart, DealerDetailDto dealerDto) {
		dealerCart.setUsername(dealerDto.getUsername());
		dealerCart.setEmail(dealerDto.getEmail());
		dealerCart.setPhoneNumber(dealerDto.getPhoneNumber());
		dealerCart.setAddress(dealerDto.getAddress());
		dealerCart.setCity(dealerDto.getCity());
		dealerCart.setState(dealerDto.getState());
		dealerCart.setBusinessName(dealerDto.getBusinessName());
		return dealerCart;
	}
	
	private boolean checkAvailabilityOfCropVolume(VolumeDto volumeDto) {
		return categoryInterface.checkAvailabilityOfCropVolume(volumeDto);
	}
	
	private boolean setAvailabilityOfCropVolume(VolumeDto volumeDto) {
		return categoryInterface.setAvailabilityOfCropVolume(volumeDto);
	}
	
	private boolean setCropVolumeBackToDB(VolumeDto volumeDto) {
		return categoryInterface.setCropVolumeBackToDB(volumeDto);
	}
	public DealerCart deleteDealerCart(int cartId) {
		Optional<DealerCart> foundCart=cartRepo.findById(cartId);
		if(foundCart.isPresent()) {
			for(Entry<Integer,Double> e:foundCart.get().getOfferIdAndKilo().entrySet()) {
//				if(!checkAvailabilityOfCropVolume(VolumeDto.builder().offerId(e.getKey())
//						.cropVolume(e.getValue()).build()))
//					throw new ApiRequestException("cropvolume is invalid");
				
				setCropVolumeBackToDB(VolumeDto.builder().offerId(e.getKey())
						.cropVolume(e.getValue()).build());
				}
			cartRepo.delete(foundCart.get());
		 return foundCart.get();
		}else {
			throw new ApiRequestException("Cart Not Found");
		}
	}

	/*
	 * This only fetch dealerCart without total amount
	 * */
	public DealerCart getDealerCart(int cartId) {
		Optional<DealerCart> foundCart=cartRepo.findById(cartId);
		if(foundCart.isPresent())
		{
			return foundCart.get();
		}
		throw new ApiRequestException("DealerCart Not Found");
	}
	
	/*
	 * This method will fetch dealerCart with total amount
	 * */
	public CartDto getDealerCartDto(int cartId) {
		Optional<DealerCart> foundCart=cartRepo.findById(cartId);
		if(foundCart.isEmpty())
		{
			throw new ApiRequestException("Cart Not Found");
		}
		double totalCost=calculateTotal(CalculateDto.builder().
				offerIdAndKilo(foundCart.get().getOfferIdAndKilo())
					.build());
		
		return CartDto.builder()
				.cartId(foundCart.get().getCartId())
				.dealerId(foundCart.get().getDealerId())
				.offerIdAndKilo(foundCart.get().getOfferIdAndKilo())
				.cropOrderList(
						categoryInterface.getCropOrderWithNameList(
								CalculateDto.builder().offerIdAndKilo(
										foundCart.get().getOfferIdAndKilo()).build()
								))
				.totalCost(totalCost)
				.build();
	}

	/*
	 * This method only set the value present in dealerCart, 
	 * if empty the value already present in the cart will remain same
	 *  
	 * */
	public DealerCart updateDealerCart(int cartId, DealerCart dealerCart) {
		Optional<DealerCart> foundCart=cartRepo.findById(cartId);
		if(!foundCart.isPresent())
		{
			return null;
		}
		foundCart.get().setOfferIdAndKilo(dealerCart.getOfferIdAndKilo().isEmpty()?foundCart.get().getOfferIdAndKilo():dealerCart.getOfferIdAndKilo());
		foundCart.get().setDealerId(dealerCart.getDealerId()<=0?foundCart.get().getDealerId():dealerCart.getDealerId());
		return foundCart.get();
		
	}
	
	public double calculateTotal(CalculateDto calculateDto) {
		return categoryInterface.calculateTotal(calculateDto);
	}
	
}
