package com.example.userservice.controller;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.userservice.dto.DealerDetailDto;
import com.example.userservice.dto.UserDto;
import com.example.userservice.model.UserDealer;
import com.example.userservice.service.UsersService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth/dealer")
public class DealerController {

	private UsersService usersService;

	public DealerController(UsersService usersService) {
		super();
		this.usersService = usersService;
	}

	@PostMapping("/register")
	public UserDealer addDealer(@Valid @RequestBody UserDealer userDealer) {
		userDealer.setCreatedDateTime(LocalDateTime.now());
		return (UserDealer) usersService.addUser(userDealer);
	}

	@PostMapping("/login")
	public String login(@Valid @RequestBody UserDto user) {
		return usersService.verify(user);
	}

	@GetMapping("/{username}")
	public ResponseEntity<UserDealer> getProfile(@PathVariable String username) {
		return new ResponseEntity<>((UserDealer) usersService.getProfile(username), HttpStatus.OK);
	}
	
	@GetMapping("/get/detail/{dealerId}")
	public ResponseEntity<DealerDetailDto> getDealerDetails(@PathVariable int dealerId){
		return new ResponseEntity<>(usersService.getDealerDetails(dealerId),HttpStatus.OK);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<UserDealer> updateProfile(@RequestBody UserDealer user, @PathVariable int id) {
		return new ResponseEntity<>(usersService.updateDealerProfile(user, id), HttpStatus.CREATED);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteProfile(@PathVariable int id) {
		return new ResponseEntity<>(usersService.deleteProfile(id), HttpStatus.OK);
	}

}
