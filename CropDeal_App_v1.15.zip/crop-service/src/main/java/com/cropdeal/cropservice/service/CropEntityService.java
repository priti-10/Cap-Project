package com.cropdeal.cropservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cropdeal.cropservice.dto.CropDto;
import com.cropdeal.cropservice.exception.ApiRequestException;
import com.cropdeal.cropservice.model.CropCategory;
import com.cropdeal.cropservice.model.CropEntity;
import com.cropdeal.cropservice.repository.CropCategoryRepo;
import com.cropdeal.cropservice.repository.CropEntityRepo;

@Service
public class CropEntityService {

	private CropEntityRepo cropEntityRepo;
	private CropCategoryRepo categoryRepo;
	private String messageCropNotFound = "CropEntity not Found!";

	public CropEntityService(CropEntityRepo cropEntityRepo, CropCategoryRepo categoryRepo) {
		super();
		this.cropEntityRepo = cropEntityRepo;
		this.categoryRepo = categoryRepo;
	}

	@Transactional
	public CropEntity addCropEntity(int categoryid, CropEntity cropEntity) {
		try {
			Optional<CropCategory> category = categoryRepo.findById(categoryid);
			if (category.isPresent()) {
				cropEntity.setCropCategory(category.get());

				return cropEntityRepo.save(cropEntity);
			} else {
				throw new ApiRequestException("CropCategory not Found!");
			}
		} catch (IllegalArgumentException e) {
			throw new ApiRequestException("IllegalArgument! or Empty Data!");
		}
	}

	public CropEntity getCropEntity(int cropId) {
		Optional<CropEntity> foundCrop = cropEntityRepo.findById(cropId);
		if (foundCrop.isEmpty()) {
			throw new ApiRequestException(messageCropNotFound);
		}
		return foundCrop.get();
	}

	public List<CropEntity> getAllCropEntity() {
		if (cropEntityRepo.findAll().isEmpty()) {
			throw new ApiRequestException("No Crop Added!");
		}
		return cropEntityRepo.findAll();
	}

	@Transactional
	public CropEntity updateCropEntityCategory(CropDto cropDto) {
		Optional<CropEntity> foundCrop = cropEntityRepo.findById(cropDto.getCropId());
		if (foundCrop.isPresent()) {
			Optional<CropCategory> foundCategory = categoryRepo.findById(cropDto.getToBeUpdatedCategoryId());
			if (foundCategory.isPresent()) {
				foundCrop.get().setCropCategory(foundCategory.get());
				return cropEntityRepo.save(foundCrop.get());
			} else {
				throw new ApiRequestException("CropCategory Not Found!");
			}
		} else {
			throw new ApiRequestException(messageCropNotFound);
		}

	}

	public CropEntity updateCropEntity(int cropId, CropEntity crop) {
		Optional<CropEntity> foundCrop = cropEntityRepo.findById(cropId);
		if(foundCrop.isPresent()) {
			foundCrop.get().setCropName(!(crop.getCropName().isEmpty()) ? crop.getCropName() : foundCrop.get().getCropName());
			return cropEntityRepo.save(foundCrop.get());
		}else {
			throw new ApiRequestException(messageCropNotFound);
		}
		
	}

	public CropEntity deleteCropEntity(int cropId) {
		Optional<CropEntity> foundCrop = cropEntityRepo.findById(cropId);
		if(foundCrop.isPresent()) {
			cropEntityRepo.delete(foundCrop.get());
			return foundCrop.get();
		}else {
			throw new ApiRequestException(messageCropNotFound);
		}
		
	}

	
}
