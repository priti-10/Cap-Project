package com.example.userservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.userservice.dto.UserDto;
import com.example.userservice.model.UserAdmin;
import com.example.userservice.model.Users;
import com.example.userservice.service.UsersService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth/admin")
public class AdminController {

	private UsersService usersService;

	public AdminController(UsersService usersService) {
		super();
		this.usersService = usersService;
	}

	@PostMapping("/register")
	public ResponseEntity<UserAdmin> addAdmin(@Valid @RequestBody UserAdmin userAdmin) {
		UserAdmin user = (UserAdmin) usersService.addUser(userAdmin);
		return new ResponseEntity<>(user, HttpStatus.CREATED);

	}

	@PostMapping("/login")
	public ResponseEntity<String> login(@Valid @RequestBody UserDto user) {
		return new ResponseEntity<>(usersService.verify(user), HttpStatus.OK);
	}

	@GetMapping("/{username}")
	public ResponseEntity<UserAdmin> getProfile(@PathVariable String username) {
		return new ResponseEntity<>((UserAdmin) usersService.getProfile(username), HttpStatus.OK);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<UserAdmin> updateProfile(@RequestBody UserAdmin user, @PathVariable int id) {
		return new ResponseEntity<>(usersService.updateAdminProfile(user, id), HttpStatus.CREATED);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteProfile(@PathVariable int id) {
		return new ResponseEntity<>(usersService.deleteProfile(id), HttpStatus.OK);
	}

	@GetMapping("/getAllProfile")
	public ResponseEntity<List<Users>> getAllProfile() {
		return new ResponseEntity<>(usersService.getAllUsers(), HttpStatus.OK);
	}
}
