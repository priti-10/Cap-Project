package com.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGateWayCropDealSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGateWayCropDealSystemApplication.class, args);
	}

}
