package com.cropdeal.paymentgateway.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("ORDER-SERVICE")
public interface OrderInteface {

	@GetMapping("/order/addorder")
	public String addOrder();
}
