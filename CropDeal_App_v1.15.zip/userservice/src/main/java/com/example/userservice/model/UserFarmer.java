package com.example.userservice.model;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@AllArgsConstructor
@NoArgsConstructor
@DiscriminatorValue("FA")
public class UserFarmer extends Users{

//	@Email(regexp = "[a-z]{5,10}@gmail\\.com")
	private String email;
//	@Pattern(regexp = "\\d{10}",message = "Invalid PhoneNumber!")
	private String phoneNumber;
	private String address;
	private String city;
	private String state;
	private List<String> cropTypes;
//	@NotNull(message = "Invalid bankAccountNumber!")
	private String bankAccountNumber;
//	@NotNull(message = "Invalid ifscCode!")
	private String ifscCode;
	private String upiId;
	private LocalDateTime createdDateTime;
	
	public UserFarmer(String username, String password, String roles, String email, String phoneNumber, String address,
			String city, String state, List<String> cropTypes, String bankAccountNumber, String ifscCode,
			String upiId) {
		super(username, password, roles);
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.city = city;
		this.state = state;
		this.cropTypes = cropTypes;
		this.bankAccountNumber = bankAccountNumber;
		this.ifscCode = ifscCode;
		this.upiId = upiId;
	}
	
}
